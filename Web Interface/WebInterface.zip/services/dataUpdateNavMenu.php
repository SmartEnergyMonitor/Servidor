<?php

if(!isset($_SESSION)){
    session_start();
}

include("dbConn.php");

mysqli_set_charset($db,"utf8");
$str="<ul class=\"flex-column flex-nowrap nav\">\n";
$sql1="SELECT QuadroID, Alias FROM Quadro";
$result1 = mysqli_query($db,$sql1);
if(mysqli_num_rows($result1) > 0) {
    while ($rowCerts1 = $result1->fetch_assoc()) {
        $str .= "<li><button class=\"btn custom type quadro\" value=\"{$rowCerts1['QuadroID']}\" id=\"{$rowCerts1['QuadroID']}\">{$rowCerts1['Alias']}</button> 
     <i class=\"nav-link collapsed fa fa-caret-down btn\" href=\"#submenu{$rowCerts1['QuadroID']}\" data-toggle=\"collapse\" data-target = \"#submenu{$rowCerts1['QuadroID']}\" ></i ></li >
        <li class=\"collapse\" id=\"submenu{$rowCerts1['QuadroID']}\" aria-expanded=\"false\">
            <ul class=\"flex-column pl-4 nav\">";

        $quadroID = $rowCerts1['QuadroID'];
        $sql2 = "SELECT Node.NodeID, Node.Alias FROM Node JOIN QuadroNode QN on Node.NodeID = QN.NodeID
              join Quadro Q on QN.QuadroID = Q.QuadroID WHERE Q.QuadroID = '$quadroID';";
        $result2 = mysqli_query($db, $sql2);
        while ($rowCerts2 = $result2->fetch_assoc()) {
            $str .= "<li class=\"nav-item\"><button class=\"btn custom type node\" value=\"{$rowCerts2['NodeID']}\" id=\"node{$rowCerts2['NodeID']}\">{$rowCerts2['Alias']}</button>
                        <i class=\"nav-link collapsed fa fa-caret-down btn\" href=\"#submenu{$rowCerts1['QuadroID']}sub{$rowCerts2['NodeID']}\"
                         data-toggle=\"collapse\" data-target=\"#submenu{$rowCerts1['QuadroID']}sub{$rowCerts2['NodeID']}\"></i></li>
                     <li class=\"collapse\" id=\"submenu{$rowCerts1['QuadroID']}sub{$rowCerts2['NodeID']}\" aria-expanded=\"false\">
                         <ul class=\"flex-column nav pl-4\"\n>";
            $nodeID = $rowCerts2['NodeID'];
            $sql3 = "SELECT Sensor.SensorID, Sensor.Alias FROM Sensor JOIN SensorNode S on Sensor.SensorID = S.SensorID 
                  join Node N on S.NodeID = N.NodeID WHERE N.NodeID = '$nodeID';";
            $result3 = mysqli_query($db, $sql3);
            while ($rowCerts3 = $result3->fetch_assoc()) {
                $str .= " <li class=\"nav-item\">
                                            <button type=\"button\" class=\"btn custom type sensor\" value=\"{$rowCerts3['SensorID']}\" id=\"circ{$rowCerts3['SensorID']}\">
                                                {$rowCerts3['Alias']}
                                            </button> <!-- <input type=\"checkbox\" class=\"compCheck\" value=\"{$rowCerts3['SensorID']}\"> -->
                                        </li>
                                        ";
            }
            $str .= "</ul>
</li>
";
        }
        $str .= "</ul>
</li>
<hr>";
    }
}
$str .= "</ul>";

mysqli_close($db);
echo $str;