<?php

if(!isset($_SESSION)){
    session_start();
}

include("dbConn.php");

$str = '';

mysqli_set_charset($db,"utf8");

$quadroID = mysqli_real_escape_string($db,$_POST['quadroID']);

$sql = "SELECT Node.NodeID, Alias FROM Node JOIN  QuadroNode ON Node.NodeID = QuadroNode.NodeID Where QuadroID = '$quadroID' GROUP BY Node.NodeID;";
$result = mysqli_query($db,$sql);
while ($rowCerts = $result->fetch_assoc()) {
    $str.= "<option value=\"{$rowCerts['NodeID']}\" class = \"NodeDropdownID\">".$rowCerts['Alias']."</option>\n";
}

mysqli_close($db);

echo $str;