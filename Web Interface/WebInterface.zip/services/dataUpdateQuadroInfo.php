<?php
if(!isset($_SESSION)){
    session_start();
}

include("dbConn.php");

mysqli_set_charset($db,"utf8");

$quadroID = mysqli_real_escape_string($db,$_POST['quadroID']);
$str="";

$sql = "Select Q.Alias AS Nome, Q.QuadroID, E.Alias as Edificio, count(DISTINCT N.NodeID)as NumeroNodes, count(S.SensorID) as NumSensor, Q.Tipo as Tipo FROM Quadro Q JOIN EdificioQuadro EQ on Q.QuadroID = EQ.QuadroID JOIN Edificio E on EQ.EdificioID = E.EdificioID left join QuadroNode QN on Q.QuadroID = QN.QuadroID left join Node N on QN.NodeID = N.NodeID left join SensorNode SN on N.NodeID = SN.NodeID left join Sensor S on SN.SensorID = S.SensorID where Q.QuadroID='$quadroID';";
$result = mysqli_query($db,$sql);
$row = mysqli_fetch_array($result,MYSQLI_ASSOC);

if($row['Tipo']==0){
    $Tipo = "Geral";
}else {
    $Tipo = "Parcial";
}




$str.="<div class=\"row\">
    <div class=\"col-md-3 col-md-offset-1\">
        <div class=\"card\">
            <div class=\"card-header\">Info</div>
            <div class=\"card-body\">
                <p>Nome: {$row['Nome']}</p>
                <p>Edificio: {$row['Edificio']}</p>
                <p>Número de Nós: {$row['NumeroNodes']}</p>
                <p>Numero de Circuitos: {$row['NumSensor']}</p>
                <p>Quadro $Tipo</p>
            </div>
        </div>
        <p></p><div class=\"card\">
            <div class=\"card\">
                <div class=\"card-header\">Nós</div>
                <div class=\"card-body\">
                    <div class=\"table-responsive\">
                        <table class=\"table\" style=\"display:block; max-height:400px; overflow-y:scroll; width:100 %;\">
                         <tbody>";


$sql2 = "SELECT Node.Alias, Node.MACAdress AS MAC FROM Node JOIN QuadroNode QN on Node.NodeID = QN.NodeID WHERE QuadroID = '$quadroID';";
$result2 = mysqli_query($db,$sql2);
while ($rowCerts3 = $result2->fetch_assoc()) {
    $str.="<tr>
            <td>{$rowCerts3['Alias']}</td>
            <td>{$rowCerts3['MAC']}</td>
            </tr>";
}

$str.= "</tbody>
                   </table>
                  </div>
                </div>
            </div>
        </div>
    </div>

    <div class=\"col-md-8 col-md-offset-1\">
        <div class=\"card\">
            <div class=\"card-header\">Consumo total</div>
            <div class=\"card-body\">
                <div class=\"panel-body\">
                    <div class=\"flot-chart\">
                        <div class=\"flot-chart-content\" id=\"flot-line-chart1\" style=\"padding: 0px; position: relative;\">
                            <canvas class=\"flot-base\"
                                    style=\"direction: ltr; position: absolute; left: 0px; top: 0px; width: 1560px; height: 400px;\"
                                    width=\"1560\" height=\"400\"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>";

mysqli_close($db);
echo $str;