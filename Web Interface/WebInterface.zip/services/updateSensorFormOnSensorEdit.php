<?php

if(!isset($_SESSION)){
    session_start();
}

include("dbConn.php");

$str = '';

mysqli_set_charset($db,"utf8");

$nodeID = mysqli_real_escape_string($db,$_POST['nodeID']);

$sql = "SELECT Sensor.SensorID, Alias FROM Sensor JOIN SensorNode ON Sensor.SensorID = SensorNode.SensorID Where SensorNode.NodeID = '$nodeID' GROUP BY Sensor.SensorID;";
$result = mysqli_query($db,$sql);
while ($rowCerts = $result->fetch_assoc()) {
    $str.= "<option value=\"{$rowCerts['SensorID']}\" class = \"SensorEditSensorDropdownID\">".$rowCerts['Alias']."</option>\n";
}

mysqli_close($db);

echo $str;