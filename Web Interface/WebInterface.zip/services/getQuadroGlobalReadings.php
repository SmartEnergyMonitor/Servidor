<?php
if(!isset($_SESSION)){
    session_start();
}

include("dbConn.php");

mysqli_set_charset($db,"utf8");

$quadroID = mysqli_real_escape_string($db,$_POST['quadroID']);

$sql = "Select distinct UNIX_TIMESTAMP(convert((min(Data) div 1000)*1000, datetime))*1000 as time, sum(L.Leitura) FROM Quadro Q JOIN EdificioQuadro EQ on Q.QuadroID = EQ.QuadroID JOIN Edificio E on EQ.EdificioID = E.EdificioID left join QuadroNode QN on Q.QuadroID = QN.QuadroID left join Node N on QN.NodeID = N.NodeID left join SensorNode SN on N.NodeID = SN.NodeID left join Sensor S on SN.SensorID = S.SensorID left join Leitura L on S.SensorID = L.SensorID  where Q.QuadroID='$quadroID' and DATA <= NOW() group by Data div 500;";
$result=mysqli_query($db,$sql);

$out = array();
while ($row=mysqli_fetch_array($result,MYSQLI_NUM)) {
    $out[] = array(floatval($row[0]),$row[1]);
}

echo json_encode($out);