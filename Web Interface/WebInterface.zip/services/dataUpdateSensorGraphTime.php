<?php
if(!isset($_SESSION)){
    session_start();
}

include("dbConn.php");

date_default_timezone_set("Europe/Lisbon");

mysqli_set_charset($db,"utf8");

$sensorID = mysqli_real_escape_string($db,$_GET['sensorTimeID']);
$datainit = mysqli_real_escape_string($db,$_GET['datainit']);
$datafin = mysqli_real_escape_string($db,$_GET['datafin']);


if($datafin <= $datainit) {
    echo "1";
    exit();
}

$datainitTS = strtotime($datainit);
$datafinTS = strtotime($datafin);


$sql = "SELECT UNIX_TIMESTAMP(Data)*1000 as TIME, L.Leitura as VALOR FROM Sensor S JOIN Leitura L on S.SensorID = L.SensorID WHERE L.SensorID = '$sensorID' AND Data BETWEEN FROM_UNIXTIME('$datainitTS') AND FROM_UNIXTIME('$datafinTS');";
$result=mysqli_query($db,$sql);

$out = array();
while ($row=mysqli_fetch_array($result,MYSQLI_NUM)) {
    $out[] = array(floatval($row[0]),$row[1]);
}

echo json_encode($out);

