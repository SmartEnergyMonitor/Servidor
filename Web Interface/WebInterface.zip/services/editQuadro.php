<?php

if(!isset($_SESSION)){
    session_start();
}

include("dbConn.php");

mysqli_set_charset($db,"utf8");

$quadroID = mysqli_real_escape_string($db,$_POST['quadroOld']);
$nameQuadroNew = mysqli_real_escape_string($db,$_POST['nameQuadroNew']);

$sql="UPDATE Quadro SET Alias = '$nameQuadroNew' WHERE QuadroID = '$quadroID'";
$result = mysqli_query($db,$sql);

mysqli_close($db);

