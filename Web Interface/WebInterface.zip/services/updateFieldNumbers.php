<?php

if(!isset($_SESSION)){
    session_start();
}

include("dbConn.php");

mysqli_set_charset($db,"utf8");

$sql1="SELECT COUNT(QuadroID) AS NumberOfQuadros FROM Quadro;";
$result = mysqli_query($db,$sql1);
if(mysqli_num_rows($result) > 0) {
    while ($rowCerts = $result->fetch_assoc()) {
        $str1 = "<h1 class=\"display-1 text-center\">".$rowCerts['NumberOfQuadros']."</h1>";
    }
}

$sql2="SELECT COUNT(NodeID) AS NumberOfNodes FROM Node WHERE Alias IS NOT NULL;";
$result = mysqli_query($db,$sql2);
if(mysqli_num_rows($result) > 0) {
    while ($rowCerts = $result->fetch_assoc()) {
        $str2 = "<h1 class=\"display-1 text-center\">".$rowCerts['NumberOfNodes']."</h1>";
    }
}

$sql3="SELECT COUNT(SensorID) AS NumberOfSensors FROM Sensor;";
$result = mysqli_query($db,$sql3);
if(mysqli_num_rows($result) > 0) {
    while ($rowCerts = $result->fetch_assoc()) {
        $str3 = "<h1 class=\"display-1 text-center\">".$rowCerts['NumberOfSensors']."</h1>";
    }
}

mysqli_close($db);

$out = array($str1,$str2,$str3);
echo json_encode($out);


