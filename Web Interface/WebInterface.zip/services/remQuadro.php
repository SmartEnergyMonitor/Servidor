<?php

if(!isset($_SESSION)){
    session_start();
}

include("dbConn.php");

mysqli_set_charset($db,"utf8");


$idQuadro = mysqli_real_escape_string($db,$_POST['remQuadroID']);

$sql="DELETE FROM Sensor WHERE SensorID = (SELECT SensorNode.SensorID from SensorNode join Node on SensorNode.NodeID = Node.NodeID join QuadroNode on SensorNode.NodeID = QuadroNode.NodeId join Quadro on QuadroNode.QuadroID = Quadro.QuadroID where Quadro.QuadroID='$idQuadro' group by SensorNode.SensorID)";
$result = mysqli_query($db,$sql);

$sql="DELETE FROM Node WHERE NodeID = (SELECT QuadroNode.NodeID from QuadroNode JOIN Quadro ON QuadroNode.QuadroID = Quadro.QuadroID WHERE Quadro.QuadroID = '$idQuadro')";
$result = mysqli_query($db,$sql);


$sql="DELETE FROM Quadro WHERE QuadroID = '$idQuadro'";
$result = mysqli_query($db,$sql);


mysqli_close($db);

echo $idQuadro;