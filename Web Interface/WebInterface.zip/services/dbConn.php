
<?php

    define('DB_SERVER', 'localhost');

    define('DB_USERNAME', 'remoteUser');

    define('DB_PASSWORD', 'password');

    define('DB_NAME', 'energy');

    $db = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

    if($db === false){
        die("ERROR: Could not connect. " . mysqli_connect_error());
    }
?>


