<?php
if(!isset($_SESSION)){
    session_start();
}

include("dbConn.php");

mysqli_set_charset($db,"utf8");

$nodeID = mysqli_real_escape_string($db,$_POST['nodeID']);
$str="";

$sql = "SELECT N.Alias as Node, Q.Alias as Quadro FROM Node N JOIN QuadroNode QN on N.NodeID = QN.NodeID JOIN Quadro Q on QN.QuadroID = Q.QuadroID where N.NodeID = '$nodeID'";
$result = mysqli_query($db,$sql);
$row = $result->fetch_assoc();

$str .= "<div class=\"row\">
    <div class=\"col-md-3 col-md-offset-1\"> <!-- primeira tabela -->
        <div class=\"card\">
            <div class=\"card-header\">Info</div>
            <div class=\"card-body\">
                <p>Nome: {$row['Node']}</p>
                <p>Quadro: {$row['Quadro']}</p>
            </div>
        </div>
    </div>
    <div class=\"col-md-6 col-md-offset-1\"> <!-- 2a tabela -->
        <div class=\"card\">
            <div class=\"card-header\">Circuitos</div>
            <div class=\"card-body\">
                <div class=\"table-responsive\">
                    <table class=\"table\" style=\"display:block; max-height:450px; overflow-y:scroll;\">
                        <thead class=\"thead-light\" style=\"display:table; width:100%; table-layout:fixed;\">
                        <tr>
                            <th>Circuito</th>
                            <th>Número da Placa</th>
                            <th>Canal</th>
                        </tr>
                        </thead>
                        <tbody>";

$sql2 = "select S.Alias AS Nome, S.I2CAdress as I2C,S.Canal as Canal FROM Sensor S JOIN SensorNode SN on S.SensorID = SN.SensorID JOIN Node N on SN.NodeID = N.NodeID WHERE N.NodeID='$nodeID'";
$result2 = mysqli_query($db,$sql2);

while($rowCerts = $result2->fetch_assoc()) {
    $str .= " <tr style=\"display:table; width:100%; table-layout:fixed;\">
                            <td>{$rowCerts['Nome']}</td>
                            <td>{$rowCerts['I2C']}</td>
                            <td>{$rowCerts['Canal']}</td>
                        </tr>";
}

$str .= " </tbody>
                    </table> <!-- Tabela -->
                </div>

            </div>
        </div>
    </div>
</div>";

mysqli_close($db);
echo $str;