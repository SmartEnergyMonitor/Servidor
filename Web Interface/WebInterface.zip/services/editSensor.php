<?php

if(!isset($_SESSION)){
    session_start();
}

include("dbConn.php");

mysqli_set_charset($db,"utf8");

$sensorID = mysqli_real_escape_string($db,$_POST['sensorOld']);
$nameSensorNew = mysqli_real_escape_string($db,$_POST['nameSensorNew']);

$sql="UPDATE Sensor SET Alias = '$nameSensorNew' WHERE SensorID = '$sensorID'";
$result = mysqli_query($db,$sql);

mysqli_close($db);

echo $sensorID.':'.$nameSensorNew;