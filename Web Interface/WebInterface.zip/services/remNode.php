<?php

if(!isset($_SESSION)){
    session_start();
}

include("dbConn.php");

mysqli_set_charset($db,"utf8");


$idNode = mysqli_real_escape_string($db,$_POST['remNodeID']);

$sql="DELETE FROM Sensor WHERE SensorID = (SELECT SensorNode.SensorID from SensorNode join Node on SensorNode.NodeID = Node.NodeID where Node.NodeID='$idNode' group by Sensor.SensorID)";
$result = mysqli_query($db,$sql);

$sql="DELETE FROM Node WHERE NodeID = '$idNode'";
$result = mysqli_query($db,$sql);

mysqli_close($db);
