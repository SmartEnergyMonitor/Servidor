<?php
if(!isset($_SESSION)){
    session_start();
}

include("dbConn.php");

mysqli_set_charset($db,"utf8");

$sql="select Sensor.SensorID, Sensor.Alias, sum(Leitura) from (SELECT * from Leitura) AS ABC 
Join Sensor on Sensor.SensorID = ABC.SensorID GROUP BY SensorID ORDER BY sum(Leitura) DESC LIMIT 5;";
$result=mysqli_query($db,$sql);

$out = array();
while ($row=mysqli_fetch_array($result,MYSQLI_NUM)) {
    $out[] = array('label' => $row[1], "data" => $row[2]);
}

echo json_encode($out);