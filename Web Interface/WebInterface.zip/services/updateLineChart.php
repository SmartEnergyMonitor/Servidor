<?php
if(!isset($_SESSION)){
    session_start();
}

include("dbConn.php");

mysqli_set_charset($db,"utf8");

$sensorID = mysqli_real_escape_string($db,$_POST['sensorID']);

$sql="select UNIX_TIMESTAMP(Data)*1000 as TIME, Leitura from Leitura where sensorID= '$sensorID';";
$result=mysqli_query($db,$sql);

$out = array();
while ($row=mysqli_fetch_array($result,MYSQLI_NUM)) {
    $out[] = array(floatval($row[0]),$row[1]);
}

echo json_encode($out);

