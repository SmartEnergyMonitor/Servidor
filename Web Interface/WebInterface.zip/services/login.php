<?php

include("dbConn.php");
session_start();




// username and password sent from form

$myusername = mysqli_real_escape_string($db,$_POST['username']);
//$mypassword = hash("sha512",mysqli_real_escape_string($db,$_POST['password']));
$mypassword = mysqli_real_escape_string($db,$_POST['password']);
$sql = "SELECT UserId FROM Users WHERE Username = '$myusername' and Password = '$mypassword'";
$result = mysqli_query($db,$sql);
$row = mysqli_fetch_array($result,MYSQLI_ASSOC);
$active = $row['active'];



$count = mysqli_num_rows($result);
// If result matched $myusername and $mypassword, table row must be 1 row

if($count == 1) {
    echo"sad1";

    $_SESSION['login_user'] = $myusername;
    header("location: /pages/main.php");
    exit();
}else {
    $error = "Your Login Name or Password is invalid";
    echo $error;
}



