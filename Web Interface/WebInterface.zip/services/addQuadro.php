<head> <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script></head>

<?php
if(!isset($_SESSION)){
    session_start();
}

include("dbConn.php");

mysqli_set_charset($db,"utf8");

$nameQuadro = mysqli_real_escape_string($db,$_POST['nameQuadro']);
$building = mysqli_real_escape_string($db,$_POST['building']);
$nameGeneral = mysqli_real_escape_string($db,$_POST['nameGeneral']);

$sql = "INSERT INTO Edificio (Alias) VALUES ('$building')";
$result = mysqli_query($db,$sql);

$sql = "SELECT EdificioID FROM Edificio WHERE Alias= '$building'";
$result = mysqli_query($db,$sql);
$row = mysqli_fetch_all($result,MYSQLI_ASSOC);
$idEdificio = $row[0]['EdificioID'];

if($_POST['quadroCheck'] == '1') {
    $sql = "INSERT INTO Quadro (Alias, Tipo, ParentID) VALUES ('$nameQuadro','1','$nameGeneral')";
    $result = mysqli_query($db,$sql);

} else{
    $sql = "INSERT INTO Quadro (Alias, Tipo) VALUES ('$nameQuadro','0')";
    $result = mysqli_query($db,$sql);
}

$sql = "SELECT QuadroID FROM Quadro WHERE Alias= '$nameQuadro'";
$result = mysqli_query($db,$sql);
$row = mysqli_fetch_all($result,MYSQLI_ASSOC);
$idQuadro = $row[0]['QuadroID'];

$sql = "INSERT INTO EdificioQuadro (EdificioID, QuadroID) VALUES ('$idEdificio','$idQuadro')";
$result = mysqli_query($db,$sql);

mysqli_close($db);


