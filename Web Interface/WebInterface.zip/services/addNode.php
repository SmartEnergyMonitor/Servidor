<?php

if(!isset($_SESSION)){
    session_start();
}

include("dbConn.php");

mysqli_set_charset($db,"utf8");

$nameNode = mysqli_real_escape_string($db,$_POST['nameNode']);
$idQuadro = mysqli_real_escape_string($db,$_POST['idQuadro']);
$idNode = mysqli_real_escape_string($db,$_POST['idNode']);

$sql = "UPDATE Node SET Alias ='$nameNode' WHERE NodeID = '$idNode'";
$result = mysqli_query($db,$sql);

$sql = "INSERT INTO QuadroNode (QuadroID, NodeID) VALUES ('$idQuadro','$idNode')";
$result = mysqli_query($db,$sql);

mysqli_close($db);