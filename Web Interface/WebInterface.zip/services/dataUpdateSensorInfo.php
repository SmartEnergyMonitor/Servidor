<?php
if(!isset($_SESSION)){
    session_start();
}

include("dbConn.php");

mysqli_set_charset($db,"utf8");

$sensorID = mysqli_real_escape_string($db,$_POST['sensorID']);
$str="";

$sql = "SELECT S.SensorID AS ID, S.Alias AS Name, S.I2CAdress AS I2C,S.ReadType AS Leitura, S.ConnType AS CONN, S.Canal AS Canal,S.IDFase1, S.IDFase2, S.Amperagem, S.Modelo FROM Sensor S WHERE SensorID = '$sensorID'";
$result = mysqli_query($db,$sql);
$row = mysqli_fetch_assoc($result);

if($row['IDFase1']){
    $Tipo.="Trifásico";
} else {
    $Tipo.="Monofásico";
}

$str = "<div class=\"row\">
    <div class=\"col-md-3\">
        <div class=\"card\">
            <div class=\"card-header\">Info</div>
            <div class=\"card-body\">
                <p>Nome: {$row['Name']}</p>
                <p>Tipo: {$Tipo}</p>
                <p>Número da Placa:
                <style=\"margin-left: 20px\">{$row['I2C']}</>
                <p>Canal: {$row['Canal']}</p>
                <p>Tipo de Leitura: Corrente</p>
                <p>Sensor: {$row['Modelo']}</p>
                <p>Amperagem: {$row['Amperagem']}A</p>  
            </div>
        </div>
    </div>

    <div class=\"col-md-8\">
        <div class=\"card\">
            <div class=\"card-header\">Consumos</div>
            <div class=\"card-body\">
                <div class=\"row\">
                 <div class=\"col-md-12 alert alert-danger alert-dismissable collapse\" id=\"dateError\">
                    <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">×</button>
                    <a style=\"text-align: center;\">Erro: Data inicial posterior à data final.</a>
                </div>
                    <form class=\"form-inline\" method=\"GET\">
                    <div class=\"col-md-5\">
                        Data Inicial:
                        <input type=\"text\" class=\"form-control\" id=\"datainit\" name = \"datainit\">

                    </div>
                    <div class=\"col-md-5\">
                        Data Final:
                        <input type=\"text\" class=\"form-control\" id=\"datafin\" name=\"datafin\">

                    </div>
                    <input type='hidden' value=\"{$row['ID']}\" id=\"sensorTimeID\" name=\"sensorTimeID\">
                    <div class=\"col-md-2\">
                        <button id=\"timeUpdate\" class=\"btn btn-secondary\" style=\"margin-top: 23px\">Actualizar</button>
                    </div>
                    </form>
                </div>
                <hr>
                <div class=\"row\">
                    <div class=\"col-md-12\">
                        <div class=\"flot-chart\" style=\"height: 300px;\">
                            <div class=\"flot-chart-content\" id=\"flot-line-chart3\" style=\"padding: 0px; position: relative;\">
                                <canvas class=\"flot-base\"
                                        style=\"direction: ltr; position: absolute; left: 0px; top: 0px; width: 1560px; height: 50%;\"></canvas>
                            </div>
                        </div>
                    </div>
                    <div class=\"col-md-12\">
                        <div class=\"flot-chart\">
                            <div class=\"flot-chart-content\" id=\"flot-line-chart_comp\" style=\"padding: 0px; position: relative;\">
                                <canvas class=\"flot-base\"
                                        style=\"direction: ltr; position: absolute; left: 0px; top: 0px; width: 1560px; height: 50%;\"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>";

echo $str;

