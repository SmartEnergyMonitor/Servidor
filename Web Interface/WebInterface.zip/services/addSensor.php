<?php

if(!isset($_SESSION)){
    session_start();
}

include("dbConn.php");

mysqli_set_charset($db,"utf8");

$quadroSensor = mysqli_real_escape_string($db,$_POST['quadroSensor']);
$nodeSensor = mysqli_real_escape_string($db,$_POST['nodeSensor']);
$nameSensor = mysqli_real_escape_string($db,$_POST['nameSensor']);
$modeloSensor = mysqli_real_escape_string($db,$_POST['modeloSensor']);
$ampSensor = mysqli_real_escape_string($db,$_POST['ampSensor']);
$optradio = mysqli_real_escape_string($db,$_POST['optradio']);
$connMethod = mysqli_real_escape_string($db,$_POST['connMethod']);
$triTrue = mysqli_real_escape_string($db,$_POST['triTrue']);
$I2C1 = mysqli_real_escape_string($db,$_POST['I2C1']);
$I2C2 = mysqli_real_escape_string($db,$_POST['I2C2']);
$I2C3 = mysqli_real_escape_string($db,$_POST['I2C3']);
$I2C1Channel = mysqli_real_escape_string($db,$_POST['I2C1Channel']);
$I2C2Channel = mysqli_real_escape_string($db,$_POST['I2C2Channel']);
$I2C3Channel = mysqli_real_escape_string($db,$_POST['I2C3Channel']);
$AnalogPin1 = mysqli_real_escape_string($db,$_POST['AnalogPin1']);
$AnalogPin2 = mysqli_real_escape_string($db,$_POST['AnalogPin2']);
$AnalogPin3 = mysqli_real_escape_string($db,$_POST['AnalogPin3']);

if($optradio == "voltage"){
    $readType = 0;
}else {
    $readType = 1;
}

if($triTrue == 1)
{
    $nameSensor1 = $nameSensor." (fase 1)";
    $nameSensor2 = $nameSensor." (fase 2)";
    $nameSensor3 = $nameSensor." (fase 3)";

    if($connMethod == "I2C"){
        $sql1="INSERT INTO Sensor (Alias,Modelo,Amperagem,ReadType,ConnType,I2CAdress,Canal) VALUES ('$nameSensor1','$modeloSensor','$ampSensor','$readType',1, CONV('$I2C1',16,10),'$I2C1Channel')";
        $sql2="INSERT INTO Sensor (Alias,Modelo,Amperagem,ReadType,ConnType,I2CAdress,Canal) VALUES ('$nameSensor2','$modeloSensor','$ampSensor','$readType',1,CONV('$I2C1',16,10),'$I2C2Channel')";
        $sql3="INSERT INTO Sensor (Alias,Modelo,Amperagem,ReadType,ConnType,I2CAdress,Canal) VALUES ('$nameSensor3','$modeloSensor','$ampSensor','$readType',1,CONV('$I2C1',16,10),'$I2C3Channel')";

        $result1 = mysqli_query($db,$sql1);
        $result2 = mysqli_query($db,$sql2);
        $result3 = mysqli_query($db,$sql3);

        $sql="SELECT SensorID FROM Sensor WHERE Alias = '$nameSensor1'";
        $result = mysqli_query($db,$sql);
        $row = mysqli_fetch_all($result,MYSQLI_ASSOC);
        $idFase1 = $row[0]['SensorID'];

        $sql="SELECT SensorID FROM Sensor WHERE Alias = '$nameSensor2'";
        $result = mysqli_query($db,$sql);
        $row = mysqli_fetch_all($result,MYSQLI_ASSOC);
        $idFase2 = $row[0]['SensorID'];

        $sql="SELECT SensorID FROM Sensor WHERE Alias = '$nameSensor3'";
        $result = mysqli_query($db,$sql);
        $row = mysqli_fetch_all($result,MYSQLI_ASSOC);
        $idFase3 = $row[0]['SensorID'];

        $sql="INSERT INTO SensorNode (SensorID,NodeID) VALUES ('$idFase1','$nodeSensor')";
        $result = mysqli_query($db,$sql);
        $sql="INSERT INTO SensorNode (SensorID,NodeID) VALUES ('$idFase2','$nodeSensor')";
        $result = mysqli_query($db,$sql);
        $sql="INSERT INTO SensorNode (SensorID,NodeID) VALUES ('$idFase3','$nodeSensor')";
        $result = mysqli_query($db,$sql);

        $sql = "UPDATE Sensor SET IDFase1 = '$idFase2',IDFase2 = '$idFase3' WHERE SensorID = '$idFase1'";
        $result = mysqli_query($db,$sql);
        $sql = "UPDATE Sensor SET IDFase1 = '$idFase1',IDFase2 = '$idFase3' WHERE SensorID = '$idFase2'";
        $result = mysqli_query($db,$sql);
        $sql = "UPDATE Sensor SET IDFase1 = '$idFase1',IDFase2 = '$idFase2' WHERE SensorID = '$idFase3'";
        $result = mysqli_query($db,$sql);
    } else {
        $sql1 = "INSERT INTO Sensor (Alias,Modelo,Amperagem,ReadType,ConnType,Canal) VALUES ('$nameSensor1','$modeloSensor','$ampSensor','$readType',0,'$AnalogPin1')";
        $sql2 = "INSERT INTO Sensor (Alias,Modelo,Amperagem,ReadType,ConnType,Canal) VALUES ('$nameSensor2','$modeloSensor','$ampSensor','$readType',0,'$AnalogPin2')";
        $sql3 = "INSERT INTO Sensor (Alias,Modelo,Amperagem,ReadType,ConnType,Canal) VALUES ('$nameSensor3','$modeloSensor','$ampSensor','$readType',0,'$AnalogPin3')";

        $result1 = mysqli_query($db, $sql1);
        $result2 = mysqli_query($db, $sql2);
        $result3 = mysqli_query($db, $sql3);

        $sql = "SELECT SensorID FROM Sensor WHERE Alias = '$nameSensor1'";
        $result = mysqli_query($db, $sql);
        $row = mysqli_fetch_all($result, MYSQLI_ASSOC);
        $idFase1 = $row[0]['SensorID'];

        $sql = "SELECT SensorID FROM Sensor WHERE Alias = '$nameSensor2'";
        $result = mysqli_query($db, $sql);
        $row = mysqli_fetch_all($result, MYSQLI_ASSOC);
        $idFase2 = $row[0]['SensorID'];

        $sql = "SELECT SensorID FROM Sensor WHERE Alias = '$nameSensor3'";
        $result = mysqli_query($db, $sql);
        $row = mysqli_fetch_all($result, MYSQLI_ASSOC);
        $idFase3 = $row[0]['SensorID'];

        $sql = "INSERT INTO SensorNode (SensorID,NodeID) VALUES ('$idFase1','$nodeSensor')";
        $result = mysqli_query($db, $sql);
        $sql = "INSERT INTO SensorNode (SensorID,NodeID) VALUES ('$idFase2','$nodeSensor')";
        $result = mysqli_query($db, $sql);
        $sql = "INSERT INTO SensorNode (SensorID,NodeID) VALUES ('$idFase3','$nodeSensor')";
        $result = mysqli_query($db, $sql);

        $sql = "UPDATE Sensor SET IDFase1 = '$idFase2',IDFase2 = '$idFase3' WHERE SensorID = '$idFase1'";
        $result = mysqli_query($db, $sql);
        $sql = "UPDATE Sensor SET IDFase1 = '$idFase1',IDFase2 = '$idFase3' WHERE SensorID = '$idFase2'";
        $result = mysqli_query($db, $sql);
        $sql = "UPDATE Sensor SET IDFase1 = '$idFase1',IDFase2 = '$idFase2' WHERE SensorID = '$idFase3'";
        $result = mysqli_query($db, $sql);
    }
}
else {
    if($connMethod == "I2C"){
        $sql="INSERT INTO Sensor (Alias,Modelo,Amperagem,ReadType,ConnType,I2CAdress,Canal) VALUES ('$nameSensor','$modeloSensor','$ampSensor','$readType',1,CONV('$I2C1',16,10),'$I2C1Channel')";
        $result1 = mysqli_query($db, $sql);

        $sql = "SELECT SensorID FROM Sensor WHERE Alias = '$nameSensor'";
        $result = mysqli_query($db, $sql);
        $row = mysqli_fetch_all($result, MYSQLI_ASSOC);
        $idSensor = $row[0]['SensorID'];

        $sql="INSERT INTO SensorNode (SensorID,NodeID) VALUES ('$idSensor','$nodeSensor')";
        $result = mysqli_query($db,$sql);
    } else {
        $sql="INSERT INTO Sensor (Alias,Modelo,Amperagem,ReadType,ConnType,Canal) VALUES ('$nameSensor','$modeloSensor','$ampSensor','$readType',0,'$AnalogPin1')";
        $result1 = mysqli_query($db, $sql);

        $sql = "SELECT SensorID FROM Sensor WHERE Alias = '$nameSensor'";
        $result = mysqli_query($db, $sql);
        $row = mysqli_fetch_all($result, MYSQLI_ASSOC);
        $idSensor = $row[0]['SensorID'];

        $sql="INSERT INTO SensorNode (SensorID,NodeID) VALUES ('$idSensor','$nodeSensor')";
        $result = mysqli_query($db,$sql);
    }

}

mysqli_close($db);



