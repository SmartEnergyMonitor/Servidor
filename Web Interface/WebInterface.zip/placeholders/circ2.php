
<link rel="stylesheet" href="../dist/css/bootstrap-datetimepicker.min.css">
<script src="../dist/js/bootstrap-datetimepicker.min.js"></script>

<body>
<div class="row">
    <div class="col-md-3">
        <div class="card">
            <div class="card-header">Info</div>
            <div class="card-body">
                <p>Nome: Circuito 2</p>
                <p>Nó: Node 1</p>
                <p>Quadro: Quadro 1</p>
                <p>Tipo: Monofásico</p>
                <p>Inputs de Arduino:</p>
                <p style="margin-left: 20px">pin 8</p>
                <p style="margin-left: 20px">pin 8</p>
                <p>Tipo de Leitura: Corrente</p>
                <p>Nº de Leituras: 32</p>
                <p>Sensor: XXXXXXX</p>
                <p>Amperagem: 20A</p>
                <p>Consumo Total: 9999 Kw</p>
                <p>Consumo Médio: 9999 Kw/h</p>

            </div>
        </div>
    </div>

    <div class="col-md-9">
        <div class="card">
            <div class="card-header">Consumos</div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-5">
                        Data Incial:
                        <input type="text" class="form-control" id="datainit">

                    </div>
                    <div class="col-md-5">
                        Data Final:
                        <input type="text" class="form-control" id="datafin">

                    </div>

                    <div class="col-md-2">
                        <button type="submit" class="btn btn-secondary" style="margin-top: 23px">Actualizar</button>
                    </div>

                </div>
                <hr>
                <div class="row">
                    <div class="col-md-12">
                        <div class="flot-chart">
                            <div class="flot-chart-content" id="flot-line-chart4" style="padding: 0px; position: relative;">
                                <canvas class="flot-base"
                                        style="direction: ltr; position: absolute; left: 0px; top: 0px; width: 1560px; height: 400px;"
                                        width="1560" height="400"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(function () {
        $('#datainit').datetimepicker();
    });
    $(function () {
        $('#datafin').datetimepicker();
    });
</script>
</body>