

$(document).ready(function(){
    $("#quadro1").click(function(){
        $("#main").load("../placeholders/quadro1.html", function() {
            var offset = 10000;
            plot();

            function plot() {
                var sin = [];
                for (var i = 0; i < 12; i += 0.2) {
                    sin.push([i, i+60]);
                }

                var options = {
                    series: {
                        lines: {
                            show: true
                        },
                        points: {
                            show: true
                        }
                    },
                    grid: {
                        hoverable: true //IMPORTANT! this is needed for tooltip to work
                    },
                    yaxis: {
                        min: -1.2,
                        max: 100
                    },
                    tooltip: true,
                    tooltipOpts: {
                        content: "'%s' of %x.1 is %y.4",
                        shifts: {
                            x: -60,
                            y: 25
                        }
                    }
                };

                var plotObj = $.plot($("#flot-line-chart1"), [{
                        data: sin,
                        label: "Consumos"
                    }],
                    options);
            }
        });
    });
});

$(document).ready(function(){
    $("#quadro2").click(function(){
        $("#main").load("../placeholders/quadro2.html", function() {
            var offset = 10000;
            plot();

            function plot() {
                var fase1 = [];
                var fase2 = [];
                var fase3 = [];
                var total =[];

                for (var i = 12; i >=0; i -= 0.2) {
                    fase1.push([12-i, i+20]);
                }
                for (var i = 0; i < 12; i += 0.2) {
                    fase2.push([i, i+20]);
                }
                for (var i = 0; i < 12; i += 0.2) {
                    fase3.push([i, i+26]);
                }
                for (var i = 0; i < 12; i += 0.2) {
                    total.push([i, fase1[i]+fase2[i]+fase3[i]]);
                }




                var options = {
                    series: {
                        lines: {
                            show: true
                        },
                        points: {
                            show: true
                        }
                    },
                    grid: {
                        hoverable: true //IMPORTANT! this is needed for tooltip to work
                    },
                    yaxis: {
                        min: -1.2,
                        max: 100
                    },
                    tooltip: true,
                    tooltipOpts: {
                        content: "'%s' of %x.1 is %y.4",
                        shifts: {
                            x: -60,
                            y: 25
                        }
                    }
                };

                var plotObj = $.plot($("#flot-line-chart4"), [{
                        data: fase1,
                        label: "fase1"
                    }, {
                        data: fase2,
                        label: "fase2"
                    }, {
                        data: fase3,
                        label: "fase3"
                    } , {
                        data: total,
                        label: "total"
                    }],
                    options);
            }
        });
    });
});


$(document).ready(function(){
    $("#no").click(function(){
        $("#main").load("../placeholders/node1.html")
    });
});


$(document).ready(function(){
    $("#circ1").click(function(){
        $("#main").load("../placeholders/circ1.php", function() {
            var offset = 10000;
            plot();

            function plot() {
                var fase1 = [];
                var fase2 = [];
                var fase3 = [];
                var total = [];

                for (var i = 12; i >=0; i -= 0.2) {
                    fase1.push([12-i, i+20]);
                }
                for (var i = 0; i < 12; i += 0.2) {
                    fase2.push([i, i+20]);
                }
                for (var i = 0; i < 12; i += 0.2) {
                    fase3.push([i, i+26]);
                }
                for (var i = 0; i < 12; i += 0.2) {
                    total.push([i, i+20+i+20-i+20]);
                }




                var options = {
                    series: {
                        lines: {
                            show: true
                        },
                        points: {
                            show: true
                        }
                    },
                    grid: {
                        hoverable: true //IMPORTANT! this is needed for tooltip to work
                    },
                    yaxis: {
                        min: -1.2,
                        max: 100
                    },
                    tooltip: true,
                    tooltipOpts: {
                        content: "'%s' of %x.1 is %y.4",
                        shifts: {
                            x: -60,
                            y: 25
                        }
                    }
                };

                var plotObj = $.plot($("#flot-line-chart3"), [{
                        data: fase1,
                        label: "fase1"
                    }, {
                        data: fase2,
                        label: "fase2"
                    }, {
                        data: fase3,
                        label: "fase3"
                    } , {
                        data: total,
                        label: "total"
                    }],
                    options);
            }
        });
    });
});

$(document).ready(function(){
    $("#circ2").click(function(){
        $("#main").load("../placeholders/circ2.php", function() {
            var offset = 10000;
            plot();

            function plot() {
                var sin = [];
                for (var i = 12; i >=0; i -= 0.2) {
                    sin.push([12-i, i+60]);
                }

                var options = {
                    series: {
                        lines: {
                            show: true
                        },
                        points: {
                            show: true
                        }
                    },
                    grid: {
                        hoverable: true //IMPORTANT! this is needed for tooltip to work
                    },
                    yaxis: {
                        min: -1.2,
                        max: 100
                    },
                    tooltip: true,
                    tooltipOpts: {
                        content: "'%s' of %x.1 is %y.4",
                        shifts: {
                            x: -60,
                            y: 25
                        }
                    }
                };

                var plotObj = $.plot($("#flot-line-chart4"), [{
                        data: sin,
                        label: "Consumos"
                    }],
                    options);
            }
        });
    });
});

