
<link rel="stylesheet" href="../dist/css/bootstrap-datetimepicker.min.css">
<script src="../dist/js/bootstrap-datetimepicker.min.js"></script>

<body>
<div class="row">
    <div class="col-md-3">
        <div class="card">
            <div class="card-header">Info</div>
            <div class="card-body">
                <p>Nome: Circuito 1</p>
                <p>Nó: Node 1</p>
                <p>Quadro: Quadro 1</p>
                <p>Tipo: Trifásico</p>
                <p>Endereços I2C:</p>
                <p style="margin-left: 20px">0x08</p>
                <p style="margin-left: 20px">0x09</p>
                <p style="margin-left: 20px">0x10</p>
                <p>Tipo de Leitura: Corrente</p>
                <p>Nº de Leituras: 123</p>
                <p>Sensor: XXXXXXX</p>
                <p>Amperagem: 20A</p>
                <p>Consumo Total: 9999 Kw</p>
                <p>Consumo Médio: 9999 Kw/h</p>

            </div>
        </div>
    </div>

    <div class="col-md-9">
        <div class="card">
            <div class="card-header">Consumos</div>
            <div class="card-body">
                <div class="row">
                    <form class="form-inline" action="../placeholders/time.php" method="get">
                    <div class="col-md-5">
                        Data Incial:
                        <input type="text" class="form-control" id="datainit" name = "datainit">

                    </div>
                    <div class="col-md-5">
                        Data Final:
                        <input type="text" class="form-control" id="datafin" name="datafin">

                    </div>

                    <div class="col-md-2">
                        <button type="submit" class="btn btn-secondary" style="margin-top: 23px">Actualizar</button>
                    </div>
                    </form>
                </div>
                <hr>
                <div class="row">
                    <div class="col-md-12">
                        <div class="flot-chart" style="height: 300px;">
                            <div class="flot-chart-content" id="flot-line-chart3" style="padding: 0px; position: relative;">
                                <canvas class="flot-base"
                                        style="direction: ltr; position: absolute; left: 0px; top: 0px; width: 1560px; height: 50%;"></canvas>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="flot-chart">
                            <div class="flot-chart-content" id="flot-line-chart_comp" style="padding: 0px; position: relative;">
                                <canvas class="flot-base"
                                        style="direction: ltr; position: absolute; left: 0px; top: 0px; width: 1560px; height: 50%;"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(function () {
        $('#datainit').datetimepicker();
    });
    $(function () {
        $('#datafin').datetimepicker();
    });
</script>
</body>