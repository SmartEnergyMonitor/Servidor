<?php

$datainit = $_GET['datainit'];

if (($timestamp = strtotime($datainit)) === false) {
    echo "The string ($datainit) is bogus\n";
} else {
    echo "$datainit == " . date('l dS \o\f F Y h:i:s A', $timestamp);
}

echo "\n".$timestamp;