


$(document).ready(function () {
    updateFieldNumbers();
    updatePieChart();
    updateLineChart()
});



function updateFieldNumbers() {
    $.ajax({
        type: "POST",
        url: "../services/updateFieldNumbers.php",
        dataType: "json"
    }).done(function (result) {
        $("#NumberOfQuadros").html(result[0]);
        $("#NumberOfNodes").html(result[1]);
        $("#NumberOfSensors").html(result[2]);
        //$('#debug').html(result);
    });
}


function updatePieChart() {
    $.ajax({
        type: "POST",
        url: "../services/updatePieChart.php",
        dataType: "json"
    }).done(function (result) {

        $(function() {
            var plotObj = $.plot($("#flot-pie-chart-1"), result, {
                series: {
                    pie: {
                        show: true
                    }
                },
                grid: {
                    hoverable: true
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%p.0%, %s", // show percentages, rounding to 2 decimal places
                    shifts: {
                        x: 20,
                        y: 0
                    },
                    defaultTheme: false
                }
            });
        });

        let total=0;
        for(let i=0; i<result.length;i++) {
            total += +result[i].data;
        }

        let htmlStr="";
        for(let i=0; i<result.length;i++) {
            htmlStr += "<tr><td>" + result[i].label + "</td><td>" + result[i].data + "</td><td>" + (+result[i].data*100/+total).toPrecision(4) + "</td></tr>"
        }
        $("#top5table").html(htmlStr);
    });

}


function updateLineChart() {
    $(document).on('click', '.sensorDropdownChartID', function (e) {
        document.getElementById("static-mainSensorChart").style.display = 'none';

        var value = $(this).val();

        $.ajax({
            url: "../services/updateLineChart.php",
            type: "POST",
            data: {sensorID: value}
        }).done(function (result) {
            var data = JSON.parse(result);
            console.log(data);
            $(function() {
                function doPlot(position) {
                    var epochT = (new Date).getTime(); // time right now in js epoch
                    $.plot($("#flot-line-chart-multi"), [{
                        data: data,
                        label: "Valor",
                        yaxis: 2
                    }], {
                        xaxes: [{
                            mode: 'time',
                            timeformat: "%d:%m:%Y - %I:%M %p",
                            //tickSize: [10,"minute"],
                            twelveHourClock: true,
                            min: epochT - 86400000, // time right now - 24 hours ago in milliseonds
                            max: epochT,
                            timezone: "browser"
                        }],
                        yaxes: [{
                            min: 0
                        }, {
                            // align if we are to the right
                            alignTicksWithAxis: position == "right" ? 1 : null,
                            position: position,
                        }],
                        legend: {
                            position: 'sw'
                        },
                        series: {
                            lines: {
                                show: true
                            },
                            points: {
                                show: true
                            }
                        },
                        grid: {
                            hoverable: true //IMPORTANT! this is needed for tooltip to work
                        },
                        tooltip: true,
                        tooltipOpts: {
                            content: "%s for %x was %y",
                            xDateFormat: "%I:%M %p",

                            onHover: function(flotItem, $tooltipEl) {
                                 console.log(flotItem, $tooltipEl);
                            }
                        }

                    });
                }

                doPlot("right");

                $("button").click(function() {
                    doPlot($(this).text());
                });
            });
        });
    })
}
