$(document).ready(function () {
    addQuadro();
    addNode();
    updateSensorNodeForm();
    addSensor();
    pageLayoutAddSensor();
});

function addQuadro() {
    $("#addQuadro").click(function (e) {
        var building = $("#building").val();
        var nameQuadro = $("#nameQuadro").val();
        var nameGeneral = $("#nameGeneral").val();
        var quadroCheck = '';
        if (document.getElementById('quadroCheck').checked) {
            quadroCheck = '1';
        } else {
            quadroCheck = '0';
        }

        $.ajax({
            url: "../services/addQuadro.php",
            type: "POST",
            data: {nameQuadro: nameQuadro, building: building, quadroCheck: quadroCheck, nameGeneral: nameGeneral}
        }).done(function (result) {
            $("#building").val('');
            $("#nameQuadro").val('');
            $("#quadroGeralInput").load(" #quadroGeralInput");
            //$('#debug').html(result);
        });
        e.preventDefault();
    })
}

function addNode() {
    $("#addNode").click(function (e) {
        var nameNode = $("#nameNode").val();
        var idQuadro = $("#idQuadro").val();
        var idNode = $("#idNode").val();

        $.ajax({
            url: "../services/addNode.php",
            type: "POST",
            data: {nameNode: nameNode, idQuadro: idQuadro, idNode: idNode}
        }).done(function (result) {
            $("#nameNode").val('');
            $("#MACAddForm").load(" #MACAddForm");

            //$('#debug').html(result);
        });
        e.preventDefault();
    })
}

function addSensor() {
    $("#addSensor").click(function (e) {

        var quadroSensor = $("#quadroSensor").val();
        var nodeSensor = $("#nodeSensor").val();
        var nameSensor = $("#nameSensor").val();
        var modeloSensor = $("#modeloSensor").val();
        var ampSensor = $("#ampSensor").val();
        var optradio = $(".optradio:checked").val();
        var connMethod = $("#activeTab").val();
        var triTrue = '';
        if (document.getElementById('triTrue').checked) {
            triTrue = '1';
        } else {
            triTrue = '0';
        }
        var I2C1 = $("#I2C1").val();
        var I2C2 = $("#I2C2").val();
        var I2C3 = $("#I2C3").val();
        var I2C1Channel = $("#I2C1Channel").val();
        var I2C2Channel = $("#I2C2Channel").val();
        var I2C3Channel = $("#I2C3Channel").val();
        var AnalogPin1 = $("#AnalogPin1").val();
        var AnalogPin2 = $("#AnalogPin2").val();
        var AnalogPin3 = $("#AnalogPin3").val();

        $.ajax({
            url: "../services/addSensor.php",
            type: "POST",
            data: {quadroSensor: quadroSensor, nodeSensor: nodeSensor, nameSensor: nameSensor, modeloSensor: modeloSensor, ampSensor: ampSensor, optradio: optradio, connMethod: connMethod, triTrue: triTrue, I2C1: I2C1, I2C2: I2C2, I2C3: I2C3, I2C1Channel:I2C1Channel, I2C2Channel:I2C2Channel, I2C3Channel:I2C3Channel, AnalogPin1: AnalogPin1, AnalogPin2: AnalogPin2, AnalogPin3: AnalogPin3}
        }).done(function (result) {
            //$('#debug').html(result);
            $("#idQuadroAddSensorForm").load(" #idQuadroAddSensorForm");
            $("#idNodeAddNodeForm").load(" #idNodeAddNodeForm");
            $("#nameSensor").val("");
            $("#modeloSensor").val("");
            $("#ampSensor").val("");
            $("#I2C1").val("");
            $("#I2C2").val("");
            $("#I2C3").val("");
            $("#I2C1Channel").val("");
            $("#I2C2Channel").val("");
            $("#I2C3Channel").val("");
            $("#AnalogPin1").val("");
            $("#AnalogPin2").val("");
            $("#AnalogPin3").val("");


        });
        e.preventDefault();
    })
}

function updateSensorNodeForm() {
    $(document).on('click', '.quadroDropdownID', function (e) {
        document.getElementById("static-quadroSensor").style.display = 'none';

        var value = $(this).val();

        $.ajax({
            url: "../services/updateNodeFormOnSensorAdd.php",
            type: "POST",
            data: {quadroID: value}
        }).done(function (result) {
            $('#nodeSensor').html(result);
        });
        e.preventDefault()
    })
}



function pageLayoutAddSensor() {

    var inputCheckbox = $('#triTrue'),
        I2CchShipBlock = $('#I2CInput'),
        I2CchShipBlockChannel = $('#I2CInputChannel'),
        analogchShipBlock = $('#AnalogInput');

    I2CchShipBlock.hide();
    analogchShipBlock.hide();
    I2CchShipBlockChannel.hide();

    inputCheckbox.on('click', function () {
        if ($(this).is(':checked')) {
            I2CchShipBlock.show();
            I2CchShipBlockChannel.show();
            analogchShipBlock.show();
        } else {
            I2CchShipBlock.hide();
            I2CchShipBlockChannel.hide();
            analogchShipBlock.hide();
        }
    });
}

var checkbox = $('#quadroCheck'),
    chShipBlock = $('#quadroGeralInput');

chShipBlock.hide();


checkbox.on('click', function () {
    if ($(this).is(':checked')) {
        chShipBlock.show();
        chShipBlock.find('input').attr('required', true);
    } else {
        chShipBlock.hide();
        chShipBlock.find('input').attr('required', false);
    }
});


$('#I2CLink').on('click', function () {
    $('#activeTab').attr('value', "I2C");
});

$('#ArduinoLink').on('click', function () {
    $('#activeTab').attr('value', "Analog");
});