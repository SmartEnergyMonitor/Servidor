$(document).ready(function () {
    updateEditQuadroForm();
    editQuadro();
    updateEditNodeForm();
    editNode();
    updateQuadroEditSensorForm();
    updateNodeEditSensorForm();
    editSensor();
});


function updateNodeEditSensorForm() {
    $(document).on('click', '.NodeDropdownID', function (e) {
        var value = $(this).val();

        $.ajax({
            url: "../services/updateSensorFormOnSensorEdit.php",
            type: "POST",
            data: {nodeID: value}
        }).done(function (result) {
            $('#sensorOld').html(result);
        });
        e.preventDefault();

    })
}


function updateQuadroEditSensorForm() {
    $(document).on('click', '.quadroEditSensorDropdownID', function (e) {
        document.getElementById("static-quadroEditSensor").style.display = 'none';

        var value = $(this).val();

        $.ajax({
            url: "../services/updateNodeFormOnSensorAdd.php",
            type: "POST",
            data: {quadroID: value}
        }).done(function (result) {
            $('#nodeSensorOld').html(result);
            $('#sensorOld').html(" <option id=\"static-sensorEditSensor\" style=\"display: block\">Selecione Circuito</option>");
        });
        e.preventDefault()
    })
}


function updateEditNodeForm() {
    $(document).on('click', '.quadroEditNodeDropdownID', function (e) {
        document.getElementById("static-quadroEditNode").style.display = 'none';

        var value = $(this).val();

        $.ajax({
            url: "../services/updateNodeFormOnSensorAdd.php",
            type: "POST",
            data: {quadroID: value}
        }).done(function (result) {
            $('#nodeOld').html(result);
        });
        e.preventDefault()
    })
}



function updateEditQuadroForm() {
    $(document).on('click', '.quadroEditDropdownID', function (e) {
        document.getElementById("static-quadroEdit").style.display = 'none';

        var value = $(this).val();

        $.ajax({
            url: "../services/updateNodeFormOnSensorAdd.php",
            type: "POST",
            data: {quadroID: value}
        }).done(function (result) {
            $('#nodeSensor').html(result);
        });
        e.preventDefault()
    })
}


function editQuadro() {
    $("#editQuadro").click(function (e) {
        var quadroOld = $("#quadroOld").val();
        var nameQuadroNew = $("#nameQuadroNew").val();

        $.ajax({
            url: "../services/editQuadro.php",
            type: "POST",
            data: {quadroOld: quadroOld, nameQuadroNew: nameQuadroNew}
        }).done(function (result) {
            //$('#debug').html(result);
            $("#nameQuadroNew").val("");
            $("#idQuadroEditForm").load(" #idQuadroEditForm")

        });
        e.preventDefault();
    })
}


function editNode() {
    $("#editNode").click(function (e) {
        var nodeOld = $("#nodeOld").val();
        var nameNodeNew = $("#nameNodeNew").val();

        $.ajax({
            url: "../services/editNode.php",
            type: "POST",
            data: {nodeOld: nodeOld, nameNodeNew: nameNodeNew}
        }).done(function (result) {
            //$('#debug').html(result);
            $("#idQuadroEditNodeForm").load(" #idQuadroEditNodeForm")
            $("#idNodeEditNodeForm").load(" #idNodeEditNodeForm")
            $("#nameNodeNew").val("");
        });
        e.preventDefault();
    })
}

function editSensor() {
    $("#editSensor").click(function (e) {
        var sensorOld = $("#sensorOld").val();
        var nameSensorNew = $("#nameSensorNew").val();

        $.ajax({
            url: "../services/editSensor.php",
            type: "POST",
            data: {sensorOld: sensorOld, nameSensorNew: nameSensorNew}
        }).done(function (result) {
            //$("#debug").html(result);
            $("#idQuadroEditSensorForm").load(" #idQuadroEditSensorForm");
            $("#idNodeEditSensorForm").load(" #idNodeEditSensorForm");
            $("#idSensorEditSensorForm").load(" #idSensorEditSensorForm");
            $("#nameSensorNew").val("");

        });
        e.preventDefault();
    })
}
