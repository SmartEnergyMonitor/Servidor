

$(document).ready(function () {
   remQuadro();
   updateRemoveNodeForm();
   remNode();
    updateQuadroRemoveSensorForm();
    updateNodeRemoveSensorForm();
    remSensor();
});


function remQuadro() {
    $("#remQuadro").click(function (e) {
        var remQuadroID = $("#remQuadroID").val();


        $.ajax({
            url: "../services/remQuadro.php",
            type: "POST",
            data: {remQuadroID: remQuadroID}
        }).done(function (result) {
            $('#debug').html(result);
        });
        e.preventDefault();
    })
}

function updateNodeRemoveSensorForm() {
    $(document).on('click', '.NodeDropdownID', function (e) {
        var value = $(this).val();

        $.ajax({
            url: "../services/updateSensorFormOnSensorEdit.php",
            type: "POST",
            data: {nodeID: value}
        }).done(function (result) {
            $('#sensorOld').html(result);
        });
        e.preventDefault();

    })
}


function updateQuadroRemoveSensorForm() {
    $(document).on('click', '.quadroRemoveSensorDropdownID', function (e) {
        document.getElementById("static-quadroRemoveSensor").style.display = 'none';

        var value = $(this).val();

        $.ajax({
            url: "../services/updateNodeFormOnSensorAdd.php",
            type: "POST",
            data: {quadroID: value}
        }).done(function (result) {
            $('#nodeSensorOld').html(result);
            $('#sensorOld').html(" <option id=\"static-sensorRemoveSensor\" style=\"display: block\">Selecione Circuito</option>");
        });
        e.preventDefault()
    })
}

function remNode() {
    $("#remNode").click(function (e) {
        var remNodeID = $("#nodeOld").val();


        $.ajax({
            url: "../services/remNode.php",
            type: "POST",
            data: {remNodeID: remNodeID}
        }).done(function (result) {
            $('#debug').html(result);
            $("#idQuadroRomoveNodeForm").load(" #idQuadroRomoveNodeForm");
            $("#idNodeRemoveNodeForm").load(" #idNodeRemoveNodeForm")
        });
        e.preventDefault();
    })
}

function updateRemoveNodeForm() {
    $(document).on('click', '.quadroRemoveNodeDropdownID', function (e) {
        document.getElementById("static-quadroRemoveNode").style.display = 'none';

        var value = $(this).val();

        $.ajax({
            url: "../services/updateNodeFormOnSensorAdd.php",
            type: "POST",
            data: {quadroID: value}
        }).done(function (result) {
            $('#nodeOld').html(result);
        });
        e.preventDefault()
    })
}

function remSensor() {
    $("#remSensor").click(function (e) {
        var sensorOld = $("#sensorOld").val();

        $.ajax({
            url: "../services/remSensor.php",
            type: "POST",
            data: {sensorOld: sensorOld}
        }).done(function (result) {
            $("#debug").html(result);
            $("#idQuadroRemoveSensorForm").load(" #idQuadroRemoveSensorForm");
            $("#idNodeRemoveSensorForm").load(" #idNodeRemoveSensorForm");
            $("#idSensorRemoveSensorForm").load(" #idSensorRemoveSensorForm");
        });
        e.preventDefault();
    })
}