$(document).ready(function () {
    updateNavMenu();
    updateQuadroInfoOnClick();
    updateNodeInfoOnClick();
    updateSensorInfoOnClick();
    updateSensorTimeOnClick();
    addToCompare();
});

function updateNavMenu() {
    $.ajax({
        type: "POST",
        url: "../services/dataUpdateNavMenu.php"
    }).done(function (result) {
        $('#sidebar').html(result);
        //console.log(result);
    });
};


function updateNodeInfoOnClick() {
    $(document).on('click','.node',function () {
        var value = $(this).val();
        $.ajax({
            url: "../services/dataUpdateNodeInfo.php",
            type: "POST",
            data: {nodeID: value}
        }).done(function (result) {
            //console.log(result);
            $('#main').html(result);
        });
    })
}

function updateQuadroInfoOnClick() {
    $(document).on('click','.quadro',function () {
        var value = $(this).val();

        $.ajax({
            url: "../services/dataUpdateQuadroInfo.php",
            type: "POST",
            data: {quadroID: value}
        }).done(function (result) {
            //console.log(result);
            $('#main').html(result);
            $.ajax({
                url: "../services/getQuadroGlobalReadings.php",
                type: "POST",
                data: {quadroID: value}
            }).done(function (result) {
                var data = JSON.parse(result);
                //console.log(data);
                $(function() {
                    function doPlot(position) {
                        var epochT = (new Date).getTime(); // time right now in js epoch
                        $.plot($("#flot-line-chart1"), [{
                            data: data,
                            label: "Consumo",
                            yaxis: 2
                        }], {
                            xaxes: [{
                                mode: 'time',
                                timeformat: "%d/%m/%Y - %I:%M%p",
                                tickSize: [4,"hour"],
                                twelveHourClock: true,
                                min: epochT - 86400000, // time right now - 24 hours ago in milliseonds
                                max: epochT,
                                timezone: "browser"
                            }],
                            yaxes: [{
                                min: 0
                            }, {
                                // align if we are to the right
                                alignTicksWithAxis: position == "right" ? 1 : null,
                                position: position,
                            }],
                            legend: {
                                position: 'sw'
                            },
                            series: {
                                lines: {
                                    show: true
                                },
                                points: {
                                    show: true
                                }
                            },
                            colors: ['blue'],
                            grid: {
                                hoverable: true //IMPORTANT! this is needed for tooltip to work
                            },
                            tooltip: true,
                            tooltipOpts: {
                                content: "%s - %x: %y kw/h",
                                xDateFormat: "%I:%M %p",

                                onHover: function(flotItem, $tooltipEl) {
                                    console.log(flotItem, $tooltipEl);
                                }
                            }

                        });
                    }
                    doPlot("right");
                    $("button").click(function() {
                        doPlot($(this).text());
                    });
                });
            });
        });

    });
}


function updateSensorInfoOnClick() {
    $(document).on('click','.sensor', function (e) {
        var value = $(this).val();

        $.ajax({
            url: "../services/dataUpdateSensorInfo.php",
            type: "POST",
            data: {sensorID: value}
        }).done(function (result) {
            //console.log(result);
            $('#main').html(result);
            $.ajax({
                url: "../services/dataUpdateSensorGraph.php",
                type: "POST",
                data: {sensorID: value}
            }).done(function (result) {
                var data = JSON.parse(result);
                console.log(data);
                $(function() {
                    function doPlot(position) {
                        var epochT = (new Date).getTime(); // time right now in js epoch
                        $.plot($("#flot-line-chart3"), [{
                            data: data,
                            label: "Consumo",
                            yaxis: 2
                        }], {
                            xaxes: [{
                                mode: 'time',
                                timeformat: "%d/%m/%Y - %I:%M%p",
                                tickSize: [4,"hour"],
                                twelveHourClock: true,
                                min: epochT - 86400000, // time right now - 24 hours ago in milliseonds
                                max: epochT,
                                timezone: "browser"
                            }],
                            yaxes: [{
                                min: 0
                            }, {
                                // align if we are to the right
                                alignTicksWithAxis: position == "right" ? 1 : null,
                                position: position,
                            }],
                            legend: {
                                position: 'sw'
                            },
                            series: {
                                lines: {
                                    show: true
                                },
                                points: {
                                    show: true
                                }
                            },
                            colors: ['blue'],
                            grid: {
                                hoverable: true //IMPORTANT! this is needed for tooltip to work
                            },
                            tooltip: true,
                            tooltipOpts: {
                                content: "%s - %x: %y kw/h",
                                xDateFormat: "%I:%M %p",

                                onHover: function(flotItem, $tooltipEl) {
                                    console.log(flotItem, $tooltipEl);
                                }
                            }

                        });
                    }
                    doPlot("right");
                    $("button").click(function() {
                        doPlot($(this).text());
                    });
                });
            });
        });
    })
}


function updateSensorTimeOnClick() {
    $(document).on('click','#timeUpdate', function (e) {

        var datainit = $('#datainit').val();
        var datafin = $('#datafin').val();
        var sensorID = $('#sensorTimeID').val();

        e.preventDefault();
        $.ajax({
            url: "../services/dataUpdateSensorGraphTime.php",
            type: "GET",
            data: {sensorTimeID: sensorID, datainit: datainit, datafin: datafin}
        }).done(function (result) {
                console.log(result);
                if(result == 1) {
                    $('#dateError').show();
                }
                var data = JSON.parse(result);
                console.log(data);
                $(function() {
                    function doPlot(position) {
                        //var epochT = (new Date).getTime(); // time right now in js epoch
                        $.plot($("#flot-line-chart3"), [{
                            data: data,
                            label: "Consumo",
                            yaxis: 2
                        }], {
                            xaxes: [{
                                mode: 'time',
                                timeformat: "%d:%m:%Y - %I:%M %p",
                                //tickSize: [10,"minute"],
                                twelveHourClock: true,
                                //min: epochT - 86400000, // time right now - 24 hours ago in milliseonds
                                //max: epochT,
                                timezone: "browser"
                            }],
                            yaxes: [{
                                min: 0
                            }, {
                                // align if we are to the right
                                alignTicksWithAxis: position == "right" ? 1 : null,
                                position: position,
                            }],
                            legend: {
                                position: 'sw'
                            },
                            series: {
                                lines: {
                                    show: true
                                },
                                points: {
                                    show: true
                                }
                            },
                            colors: ['blue'],
                            grid: {
                                hoverable: true //IMPORTANT! this is needed for tooltip to work
                            },
                            tooltip: true,
                            tooltipOpts: {
                                content: "%s - %x: %y kw/h",
                                xDateFormat: "%I:%M %p",

                                onHover: function(flotItem, $tooltipEl) {
                                    console.log(flotItem, $tooltipEl);
                                }
                            }

                        });
                    }
                    doPlot("right");
                    $("button").click(function() {
                        doPlot($(this).text());
                    });
                });
            }
        );
    });
}

var compArray = [];

function addToCompare() {
    $(document).on('click','.compCheck',(function(){
        var value = $(this).val();

        if ($(this).is(':checked')){
            compArray.push(value);
        }else{
            var index = compArray.indexOf(value);
            if(index >=0) {compArray.splice(index,1);}
        }
        updateCompGraph();
    }));
}


function getSensorSeries(value) {
    $.ajax({
        url: "../services/dataUpdateSensorGraph.php",
        type: "POST",
        data: {sensorID: value}
    }).done(function (result) {
        return JSON.parse(result);
    })
}


getSeriesObj = function () {
    var out = [];
        compArray.forEach(function (e) {
            var tmp = getSensorSeries(e);
            alert(tmp);
           out.push({
               data: tmp,
               label: "asd",
               yaxis: 2
           })
        });
    return out;
};

function updateCompGraph() {
    console.log("trigger");

    $(function() {
        function doPlot(position) {
            var epochT = (new Date).getTime(); // time right now in js epoch
            $.plot($("#flot-line-chart_comp"), getSeriesObj(), {
                xaxes: [{
                    mode: 'time',
                    timeformat: "%d/%m/%Y - %I:%M%p",
                    tickSize: [4,"hour"],
                    twelveHourClock: true,
                    min: epochT - 86400000, // time right now - 24 hours ago in milliseonds
                    max: epochT,
                    timezone: "browser"
                }],
                yaxes: [{
                    min: 0
                }, {
                    // align if we are to the right
                    alignTicksWithAxis: position == "right" ? 1 : null,
                    position: position,
                }],
                legend: {
                    position: 'sw'
                },
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                colors: ['blue'],
                grid: {
                    hoverable: true //IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s for %x was %y",
                    xDateFormat: "%I:%M %p",

                    onHover: function(flotItem, $tooltipEl) {
                        console.log(flotItem, $tooltipEl);
                    }
                }

            });
        }
        doPlot("right");
        $("button").click(function() {
            doPlot($(this).text());
        });
    });
}