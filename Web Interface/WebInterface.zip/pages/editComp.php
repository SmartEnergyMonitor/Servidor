<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Smart Energy Monitor</title>

    <script src="../src/jquery/jquery.min.js"></script>
    <script src="../src/popper/popper.min.js.html"></script>
    <script src="../src/bootstrap4/js/bootstrap.min.js"></script>

    <!-- Bootstrap Core CSS -->
    <link rel="stylesheet" href="../src/bootstrap4/css/bootstrap.min.css">

    <!-- MetisMenu CSS -->
    <link href="../src/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="../src/morrisjs/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../src/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">


    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>

    <![endif]-->


</head>

<body>
<div id="wrapper">

    <!-- Navigation -->
    <nav class="navbar navbar-expand-sm bg-secondary navbar-dark">
        <!-- Brand -->
        <a class="navbar-brand" href="#">
            <img src="../resources/img/templogothumb.png" alt="Logo" style="width:40px;">
        </a>

        <!-- Links -->
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a class="nav-link" href="main.php">Overview</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="data.php">Consultas</a>
            </li>
            <li class="nav-item">
                <div class="dropdown">
                    <a class="nav-link btn" data-toggle="dropdown">Gestão</a>
                    <div class="dropdown-menu" style="border-top: none !important; margin-top: -1px !important;
                    background-color: #FFF !important; border:1px solid black !important; white-space: nowrap !important; padding: 10px !important;">
                        <div class="btn-group">
                            <a type="button" class="btn btn-light nav-link" href="addComp.php" style="color: black; ">Adicionar
                                Componente</a>
                            <a type="button" class="btn btn-light nav-link" href="editComp.php" style="color: black">Editar
                                Componente</a>
                            <a type="button" class="btn btn-light nav-link" href="remComp.php" style="color: black">Remover
                                Componente</a>
                        </div>
                    </div>
                </div>
            </li>
        </ul>
        <!-- Dropdown -->

        <li class="navbar-nav dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                <i class="fa fa-user fa-fw"></i>
            </a>
            <ul class="dropdown-menu dropdown-menu-right"
                style="border-top: none; margin-top: -1px; background-color: #FFF; border:1px solid black; white-space: nowrap; padding: 10px;">
                <li><a class="dropdown-item" href="options.html"><i class="fa fa-user fa-fw"></i>Opções de Utilizador</a></li>
                <li><a class="dropdown-item" href="config.html"><i class="fa fa-gear fa-fw"></i>Configurações</a></li>
                <hr/>
                <li><a class="dropdown-item" href="../index.html"><i class="fa fa-sign-out fa-fw"></i>Logout</a></li>
            </ul>
        </li>
        <!-- /dropdown -->
    </nav>
    <!-- /Navigation -->

    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Editar Componente</h1>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <div id="debug">

        </div>
        <hr/>

        <div class="row justify-content-md-center">
            <div class="col-md-8 col-md-offset-2">
                <div class="card">
                    <div class="card-header">Componentes</div>
                    <div class="card-body">
                        <!-- Nav pills -->
                        <ul class="nav nav-tabs justify-content-center" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" data-toggle="tab" href="#quadroEdit">Quadro</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" data-toggle="tab" href="#nodeEdit">Nó</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" data-toggle="tab" href="#sensorEdit">Circuito</a>
                            </li>
                        </ul>
                        <!-- tabs -->
                        <div class="tab-content">

                            <!-- Editar Quadro -->

                            <div id="quadroEdit" class="container tab-pane active"><br>
                                <h3>Editar Quadro</h3>
                                <form method="post"">
                                    <div class="form-group" id="idQuadroEditForm">
                                        <label for="quadroOld">Quadro a Editar:</label>
                                        <select class="form-control" id="quadroOld" name="quadroOld">
                                            <option id="static-quadroEdit" style="display: block">Selecione Quadro</option>
                                            <?php
                                                include("../services/dbConn.php");
                                                $sql = "SELECT QuadroID, Alias FROM Quadro";
                                                $result = mysqli_query($db,$sql);
                                                while ($rowCerts = $result->fetch_assoc()) {
                                            echo "<option value=\"{$rowCerts['QuadroID']}\" class = \"quadroEditDropdownID\">";
                                            echo $rowCerts['Alias'];
                                            echo "</option>\n";
                                            }
                                            mysqli_close($db);
                                            ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="nameQuadroNew">Novo Nome:</label>
                                        <input type="text" class="form-control" id="nameQuadroNew" name="nomeQuadroNew">
                                    </div>
                                    <hr>
                                    <button type="submit" class="btn btn-primary" id="editQuadro">Modificar</button>
                                </form>
                            </div>
                            <!-- Editar Nó -->

                            <div id="nodeEdit" class="container tab-pane fade"><br>
                                <h3>Editar Nó</h3>
                                <form method="post" ">
                                    <div class="form-group" id="idQuadroEditNodeForm">
                                        <label for="quadroNodeOld">Quadro:</label>
                                        <select class="form-control" id="quadroNodeOld" name="quadroNodeOld">
                                            <option id="static-quadroEditNode" style="display: block">Selecione Quadro</option>
                                            <?php
                                            include("../services/dbConn.php");
                                            $sql = "SELECT QuadroID, Alias FROM Quadro";
                                            $result = mysqli_query($db,$sql);
                                            while ($rowCerts = $result->fetch_assoc()) {
                                                echo "<option value=\"{$rowCerts['QuadroID']}\" class = \"quadroEditNodeDropdownID\">";
                                                echo $rowCerts['Alias'];
                                                echo "</option>\n";
                                            }
                                            mysqli_close($db);
                                            ?>
                                        </select>
                                    </div>
                                    <div class="form-group" id="idNodeEditNodeForm">
                                        <label for="nodeOld">Nó a Editar:</label>
                                        <select class="form-control" id="nodeOld" name="nodeOld">
                                            <option id="static-nodeSensor" style="display: block">Select node</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="nameNodeNew">Novo Nome:</label>
                                        <input type="text" class="form-control" id="nameNodeNew" name="nomeNodeNew">
                                    </div>
                                    <hr>
                                    <button type="submit" class="btn btn-primary"id="editNode">Modificar</button>
                                </form>
                            </div>

                            <!-- Editar Circuito -->

                            <div id="sensorEdit" class="container tab-pane fade"><br>
                                <h3>Editar Circuito</h3>
                                <form method="post">
                                    <div class="form-group" id="idQuadroEditSensorForm">
                                        <label for="quadroNodeSensorOld">Quadro:</label>
                                        <select class="form-control" id="quadroNodeSensorOld" name="quadroNodeSensorOld">
                                            <option id="static-quadroEditSensor" style="display: block">Selecione Quadro</option>
                                            <?php
                                            include("../services/dbConn.php");
                                            $sql = "SELECT QuadroID, Alias FROM Quadro";
                                            $result = mysqli_query($db,$sql);
                                            while ($rowCerts = $result->fetch_assoc()) {
                                                echo "<option value=\"{$rowCerts['QuadroID']}\" class = \"quadroEditSensorDropdownID\">";
                                                echo $rowCerts['Alias'];
                                                echo "</option>\n";
                                            }
                                            mysqli_close($db);
                                            ?>
                                        </select>
                                    </div>
                                    <div class="form-group" id="idNodeEditSensorForm">
                                        <label for="nodeSensorOld id="idNodeEditSensorForm"">Nó:</label>
                                        <select class="form-control" id="nodeSensorOld" name="nodeSensorOld">
                                            <option id="static-nodeEditNode" style="display: block">Selecione Nó</option>
                                        </select>
                                    </div>
                                    <div class="form-group" id="idSensorEditSensorForm">
                                        <label for="sensorOld">Circuito a Editar:</label>
                                        <select class="form-control" id="sensorOld" name="sensorOld">
                                            <option id="static-sensorEditSensor" style="display: block">Selecione Circuito</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="nameSensorNew">Novo Nome:</label>
                                        <input type="text" class="form-control" id="nameSensorNew" name="nomeSensorNew">
                                    </div>
                                    <hr>
                                    <button type="submit" class="btn btn-primary" id="editSensor">Modificar</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script src="../js/editComp.js"></script>
    </div>
</body>
</html>