<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Smart Energy Monitor</title>

    <script src="../src/jquery/jquery.min.js"></script>
    <script src="../src/popper/popper.min.js.html"></script>
    <script src="../src/bootstrap4/js/bootstrap.min.js"></script>

    <!-- Bootstrap Core CSS -->
    <link rel="stylesheet" href="../src/bootstrap4/css/bootstrap.min.css">

    <!-- MetisMenu CSS -->
    <link href="../src/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="../src/morrisjs/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../src/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">


    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>

    <![endif]-->

    <script type="text/javascript">




    </script>

</head>

<body>
<div id="wrapper">

    <!-- Navigation -->
    <nav class="navbar navbar-expand-sm bg-secondary navbar-dark">
        <!-- Brand -->
        <a class="navbar-brand" href="#">
            <img src="../resources/img/templogothumb.png" alt="Logo" style="width:40px;">
        </a>

        <!-- Links -->
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a class="nav-link" href="main.php">Overview</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="data.php">Consultas</a>
            </li>
            <li class="nav-item">
                <div class="dropdown">
                    <a class="nav-link btn" data-toggle="dropdown" >Gestão</a>
                    <div class="dropdown-menu"  style="border-top: none !important; margin-top: -1px !important;
                    background-color: #FFF !important; border:1px solid black !important; white-space: nowrap !important; padding: 10px !important;">
                        <div class="btn-group">
                            <a type="button" class="btn btn-light nav-link" href="addComp.php" style="color: black; ">Adicionar Componente</a>
                            <a type="button" class="btn btn-light nav-link" href="editComp.php" style="color: black">Editar Componente</a>
                            <a type="button" class="btn btn-light nav-link" href="remComp.php" style="color: black">Remover Componente</a>
                        </div>
                    </div>
                </div>
            </li>
        </ul>
        <!-- Dropdown -->

        <li class="navbar-nav dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                <i class="fa fa-user fa-fw"></i>
            </a>
            <ul class="dropdown-menu dropdown-menu-right"
                style="border-top: none; margin-top: -1px; background-color: #FFF; border:1px solid black; white-space: nowrap; padding: 10px;">
                <li><a class="dropdown-item" href="options.html"><i class="fa fa-user fa-fw"></i>Opções de Utilizador</a></li>
                <li><a class="dropdown-item" href="config.html"><i class="fa fa-gear fa-fw"></i>Configurações</a></li>
                <hr/>
                <li><a class="dropdown-item" href="../index.html"><i class="fa fa-sign-out fa-fw"></i>Logout</a></li>
            </ul>
        </li>
        <!-- /dropdown -->
    </nav>
    <!-- /Navigation -->

    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Adicionar Componente</h1>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <div id="debug">

        </div>
        <hr/>

        <div class="row justify-content-md-center">
            <div class="col-md-8 col-md-offset-2">
                <div class="card">
                    <div class="card-header">Componentes</div>
                    <div class="card-body">
                        <!-- Nav pills -->
                        <ul class="nav nav-tabs justify-content-center" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" data-toggle="tab" href="#quadroAdd">Quadro</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" data-toggle="tab" href="#nodeAdd">Nó</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" data-toggle="tab" href="#sensorAdd">Circuito</a>
                            </li>
                        </ul>

                        <!-- Tab panes -->

                        <!-- Adicionar Node -->

                        <div class="tab-content">
                            <div id="quadroAdd" class="container tab-pane active"><br>
                                <h3>Adicionar Quadro</h3>
                                <form method="post">
                                    <div class="form-group">
                                        <label for="nameQuadro">Nome:</label>
                                        <input type="text" class="form-control" id="nameQuadro" name="nomeQuadro">
                                    </div>
                                    <div class="form-group">
                                        <label for="building">Edificio:</label>
                                        <input type="text" class="form-control" id="building" name="building">
                                    </div>
                                    <div class="form-check">
                                        <label class="form-check-label">
                                            <input type="checkbox" class="form-check-input" id="quadroCheck">Quadro Parcial
                                        </label>
                                    </div>
                                    <div class="form-group" id="quadroGeralInput">
                                        <label for="nameGeneral">Quadro Geral:</label>
                                        <select class="form-control" id="nameGeneral" name="nameGeneral">
                                            <?php

                                            include("../services/dbConn.php");
                                            $sql = "SELECT QuadroID, Alias FROM Quadro";
                                            $result = mysqli_query($db,$sql);
                                            while ($rowCerts = $result->fetch_assoc()) {
                                                echo "<option value=\"{$rowCerts['QuadroID']}\">";
                                                echo $rowCerts['Alias'];
                                                echo "</option>";
                                            }
                                            mysqli_close($db);

                                            ?>
                                        </select>
                                    </div>
                                    <hr>
                                    <button type="submit" class="btn btn-primary" id="addQuadro">Adicionar</button>
                                </form>
                            </div>

                            <!-- Adicionar Node -->

                            <div id="nodeAdd" class="container tab-pane fade"><br>
                                <h3>Adicionar Nó</h3>
                                <form method="post">
                                    <div class="form-group">
                                        <label for="nameNode">Nome:</label>
                                        <input type="text" class="form-control" id="nameNode" name="nameNode">
                                    </div>
                                    <div class="form-group" id="idQuadroAddNodeForm">
                                        <label for="quadroNode">Quadro:</label>
                                        <select class="form-control" id="idQuadro" id="idQuadro">
                                            <?php

                                            include("../services/dbConn.php");
                                            $sql = "SELECT QuadroID, Alias FROM Quadro";
                                            $result = mysqli_query($db,$sql);
                                            while ($rowCerts = $result->fetch_assoc()) {
                                                echo "<option value=\"{$rowCerts['QuadroID']}\">";
                                                echo $rowCerts['Alias'];
                                                echo "</option>";
                                            }
                                            mysqli_close($db);

                                            ?>
                                        </select>
                                    </div>
                                    <div class="form-group" id="MACAddForm">
                                        <label for="macNode">MAC Address:</label>
                                        <select class="form-control" id="idNode" name="idNode">
                                            <?php

                                            include("../services/dbConn.php");
                                            $sql = "SELECT NodeID, MACAdress FROM Node WHERE Alias IS NULL";
                                            $result = mysqli_query($db,$sql);
                                            while ($rowCerts = $result->fetch_assoc()) {
                                                echo "<option value=\"{$rowCerts['NodeID']}\">";
                                                echo $rowCerts['MACAdress'];
                                                echo "</option>\n";
                                            }
                                            mysqli_close($db);

                                            ?>
                                        </select>
                                    </div>
                                    <hr>
                                    <button type="submit" class="btn btn-primary" id="addNode">Adicionar</button>
                                </form>
                            </div>

                            <!-- Adicionar Sensor -->

                            <div id="sensorAdd" class="container tab-pane fade"><br>
                                <h3>Adicionar Circuito</h3>
                                <form method="post">
                                    <div class="form-group row">
                                        <div class="col-6">
                                            <div id="idQuadroAddSensorForm">
                                            <label for="quadroSensor" class="mr-sm-5">Quadro:</label>
                                            <select class="form-control mb-2 mr-sm-2" id="quadroSensor" name="quadroSensor">
                                                <option id="static-quadroSensor" style="display: block">Selecione Quadro</option>
                                                <?php
                                                include("../services/dbConn.php");
                                                $sql = "SELECT QuadroID, Alias FROM Quadro";
                                                $result = mysqli_query($db,$sql);
                                                while ($rowCerts = $result->fetch_assoc()) {
                                                    echo "<option value=\"{$rowCerts['QuadroID']}\" class = \"quadroDropdownID\">";
                                                    echo $rowCerts['Alias'];
                                                    echo "</option>\n";
                                                }
                                                mysqli_close($db);
                                                ?>
                                            </select>
                                        </div>
                                        </div>
                                        <div class="col-6">
                                            <div id="idNodeAddNodeForm">
                                            <label for="nodeSensor" class="mr-sm-2">Nó:</label>
                                            <select class="form-control mb-2 mr-sm-2" id="nodeSensor" name="nodeSensor">
                                                <option id="static-nodeSensor" style="display: block">Select node</option>
                                            </select>
                                        </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="nameSensor">Nome:</label>
                                        <input type="text" class="form-control" id="nameSensor" name="nameSensor">
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-6">
                                            <label for="modeloSensor" class="mr-sm-4">Modelo de Sensor:</label>
                                            <input type="text" class="form-control" id="modeloSensor" name="modeloSensor">
                                        </div>
                                        <div class="col-2">
                                            <label for="ampSensor" class="mr-sm-4">Amperagem:</label>
                                            <input type="number" min="0" class="form-control" id="ampSensor" name="ampSensor">
                                        </div>
                                        <div class="col-4">
                                           <!-- <p>Tipo de Leitura:</p> -->
                                            <div class="form-check-inline">
                                                <label class="form-check-type" for="voltage">
                                                   <!-- <input type="radio" class="form-check-input optradio" name="optradio" value="voltage">Tensão Elétrica -->
                                                </label>
                                            </div>
                                            <div class="form-check-inline">
                                                <label class="form-check-type" for="current">
                                                    <input type="hidden" class="form-check-input optradio" name="optradio" value="current" checked> <!--Corrente Elétrica-->
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-check">
                                        <label class="form-check-label" for="triTrue">
                                            <input type="checkbox" class="form-check-input" value="1" id="triTrue" name="triTrue">Trifásico
                                        </label>
                                    </div>
                                    <ul class="nav nav-tabs" role="tablist">
                                        <li class="nav-item">
                                            <a class="nav-link active" data-toggle="tab" id="I2CLink" href="#I2CSensor">I2C</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" data-toggle="tab" id="ArduinoLink" href="#ArduinoSensor">Analógico</a>
                                        </li>
                                    </ul>
                                    <input type="hidden" id="activeTab" name="connMethod" value="I2C">
                                    <div class="tab-content">
                                        <div id="I2CSensor" class="container tab-pane active"><br>
                                            <div class="form-group row">
                                                <div class="col-8">
                                                    <label for="I2C1">Número da Placa 1:</label>
                                                    <input type="text" class="form-control" id="I2C1" name="I2C1">
                                                    <div id="I2CInput">
                                                        <label for="I2C2">Número da Placa 2:</label>
                                                        <input type="text" class="form-control" id="I2C2" name="I2C2">
                                                        <label for="I2C3">Número da Placa 3:</label>
                                                        <input type="text" class="form-control" id="I2C3" name="I2C3">
                                                    </div>
                                                </div>
                                                <div class="col-4">
                                                    <label for="I2C1Channel">Canal I2C 1:</label>
                                                    <input type="text" class="form-control" id="I2C1Channel" name="I2C1Channel">
                                                    <div id="I2CInputChannel">
                                                        <label for="I2C2Channel">Canal I2C 2:</label>
                                                        <input type="text" class="form-control" id="I2C2Channel" name="I2C2Channel">
                                                        <label for="I2C3Channel">Canal I2C 3:</label>
                                                        <input type="text" class="form-control" id="I2C3Channel" name="I2C3Channel">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="ArduinoSensor" class="container tab-pane fade"><br>
                                            <div class="form-group">
                                                <label for="AnalogPin1">Pino 1:</label>
                                                <input type="text" class="form-control" id="AnalogPin1" name="AnalogPin1">
                                                </label>
                                                <div id="AnalogInput">
                                                    <label for="AnalogPin2">Pino 2:</label>
                                                    <input type="text" class="form-control" id="AnalogPin2" name="AanlogPin2">
                                                    </label>
                                                    <label for="AnalogPin3">Pino 3:</label>
                                                    <input type="text" class="form-control" id="AnalogPin3" name="AnalogPin3">
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <hr>
                                    <button type="submit" class="btn btn-primary" id="addSensor">Adicionar</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="../js/addComp.js"></script>
</div>
</body>
</html>
