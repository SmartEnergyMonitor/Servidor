<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Smart Energy Monitor</title>


    <!-- Bootstrap Core CSS -->
    <link rel="stylesheet" href="../src/bootstrap4/css/bootstrap.min.css">


    <!-- MetisMenu CSS -->
    <link href="../src/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="../src/morrisjs/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../src/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">


    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <!-- <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script> -->
    <!-- <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script> -->

    <script src="../src/jquery/jquery.min.js"></script>
    <script src="../src/popper/popper.min.js.html"></script>
    <script src="../src/bootstrap4/js/bootstrap.min.js"></script>
    <script src="../src/Moment/moment.min.js" type="text/javascript"></script>


    <script src="../placeholders/js/grapgcript.js"></script>

</head>

<body>


<div id="wrapper">

    <!-- Navigation -->
    <nav class="navbar navbar-expand-sm bg-secondary navbar-dark">
        <!-- Brand -->
        <a class="navbar-brand" href="#">
            <img src="../resources/img/templogothumb.png" alt="Logo" style="width:40px;">
        </a>

        <!-- Links -->
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a class="nav-link" href="main.php">Overview</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="data.php">Consultas</a>
            </li>
            <li class="nav-item">
                <div class="dropdown">
                    <a class="nav-link btn" data-toggle="dropdown" >Gestão</a>
                    <div class="dropdown-menu"  style="border-top: none; margin-top: -1px; background-color: #FFF; border:1px solid black; white-space: nowrap; padding: 10px;">
                        <div class="btn-group">
                            <a type="button" class="btn btn-light nav-link" href="addComp.php" style="color: black; ">Adicionar Componente</a>
                            <a type="button" class="btn btn-light nav-link" href="editComp.php" style="color: black">Editar Componente</a>
                            <a type="button" class="btn btn-light nav-link" href="remComp.php" style="color: black">Remover Componente</a>
                        </div>
                    </div>
                </div>
            </li>
        </ul>
        <!-- Dropdown -->

        <li class="navbar-nav dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                <i class="fa fa-user fa-fw"></i>
            </a>
            <ul class="dropdown-menu dropdown-menu-right"
                style="border-top: none; margin-top: -1px; background-color: #FFF; border:1px solid black; white-space: nowrap; padding: 10px;">
                <li><a class="dropdown-item" href="options.html"><i class="fa fa-user fa-fw"></i>Opções de Utilizador</a></li>
                <li><a class="dropdown-item" href="config.html"><i class="fa fa-gear fa-fw"></i>Configurações</a></li>
                <hr/>
                <li><a class="dropdown-item" href="../index.html"><i class="fa fa-sign-out fa-fw"></i>Logout</a></li>
            </ul>
        </li>
        <!-- /dropdown -->
    </nav>
    <!-- /Navigation -->


    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Consultas</h1>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <hr/>

        <div class="row">
            <div class="col-md-md-2">
                <nav class="navbar bg-light" id="sidebar"
                     style="min-width: 200px; max-width: 300px; background: #f8f8f8 !important; border-right: 1px solid rgba(0,0,0,.1) !important;">
                    <ul class="flex-column flex-nowrap nav">
                        <li><button class="btn custom type" id="quadro1">Quadro 1 </button> <i class="nav-link collapsed fa fa-caret-down btn"
                                                                         href="#submenu1" data-toggle="collapse"
                                                                         data-target="#submenu1"></i></li>
                        <li class="collapse" id="submenu1" aria-expanded="false">
                            <ul class="flex-column pl-4 nav">
                                <li class="nav-item"><button class="btn custom type" id="no">Node 1</button><i
                                            class="nav-link collapsed fa fa-caret-down btn" href="#submenu1sub1"
                                            data-toggle="collapse" data-target="#submenu1sub1"></i></li>
                                <li class="collapse" id="submenu1sub1" aria-expanded="false">
                                    <ul class="flex-column nav pl-4">
                                        <li class="nav-item">
                                            <button type="button" class="btn custom type" id="circ1">
                                                Circuito 1
                                            </button><input type="checkbox" id="myCheck" value="1" onclick="myFunction()">
                                        </li>
                                        <li class="nav-item">
                                            <button class="btn custom type" id="circ2">
                                                Circuito 2
                                            </button>
                                        </li>
                                        <li class="nav-item">
                                            <button class="btn custom type" id="circ3">
                                                Circuito 3
                                            </button>
                                        </li>
                                        <li class="nav-item">
                                            <button class="btn custom type" id="circ4">
                                                Circuito 4
                                            </button>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                        <hr>
                    </ul>
                </nav>
            </div>

            <div class="col-md-10 col-md-offset-1 col-sm-6" id="main">


            </div>
        </div>
    </div>
    <script>
        $(".type").click(function(){
            $(".type").removeClass("active");
            $(this).addClass("active");
        });

        function myFunction() {
            var checkBox = document.getElementById("myCheck");
            var value = checkBox.getAttribute("Value");

            if (checkBox.checked == true){
                alert(value);
            }else{
                alert("uncheck");
            }
        }
    </script>

    <script src="../src/flot/excanvas.min.js"></script>
    <script src="../src/flot/jquery.flot.js"></script>
    <script src="../src/flot/jquery.flot.pie.js"></script>
    <script src="../src/flot/jquery.flot.resize.js"></script>
    <script src="../src/flot/jquery.flot.time.js"></script>
    <script src="../src/flot-tooltip/jquery.flot.tooltip.min.js"></script>


</body>