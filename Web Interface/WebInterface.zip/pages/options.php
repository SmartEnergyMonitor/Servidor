<?php
// Include config file
require_once '/Services/dbConn.php';
 
// Define variables and initialize with empty values
$username = $password = $confirm_password = "";
$username_err = $password_err = $confirm_password_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    // Validate username
    if(empty(trim($_POST["username"]))){
        $username_err = "Please enter a username.";
    } else{
        // Prepare a select statement
        $sql = "SELECT id FROM users WHERE username = ?";
        
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_username);
            
            // Set parameters
            $param_username = trim($_POST["username"]);
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                /* store result */
                mysqli_stmt_store_result($stmt);
                
                if(mysqli_stmt_num_rows($stmt) == 1){
                    $username_err = "This username is already taken.";
                } else{
                    $username = trim($_POST["username"]);
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
        }
         
        // Close statement
        mysqli_stmt_close($stmt);
    }
    
    // Validate password
    if(empty(trim($_POST['password']))){
        $password_err = "Please enter a password.";     
    } elseif(strlen(trim($_POST['password'])) < 6){
        $password_err = "Password must have atleast 6 characters.";
    } else{
        $password = trim($_POST['password']);
    }
    
    // Validate confirm password
    if(empty(trim($_POST["confirm_password"]))){
        $confirm_password_err = 'Please confirm password.';     
    } else{
        $confirm_password = trim($_POST['confirm_password']);
        if($password != $confirm_password){
            $confirm_password_err = 'Password did not match.';
        }
    }
    
    // Check input errors before inserting in database
    if(empty($username_err) && empty($password_err) && empty($confirm_password_err)){
        
        // Prepare an insert statement
        $sql = "INSERT INTO users (username, password) VALUES (?, ?)";
         
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ss", $param_username, $param_password);
            
            // Set parameters
            $param_username = $username;
            $param_password = password_hash($password, PASSWORD_DEFAULT); // Creates a password hash
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Redirect to login page
                header("location: login.php");
            } else{
                echo "Something went wrong. Please try again later.";
            }
        }
         
        // Close statement
        mysqli_stmt_close($stmt);
    }
    
    // Close connection
    mysqli_close($link);
}
?>



<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Smart Energy Monitor</title>

    <script src="../src/jquery/jquery.min.js"></script>
    <script src="../src/popper/popper.min.js.html"></script>
    <script src="../src/bootstrap4/js/bootstrap.min.js"></script>

    <!-- Bootstrap Core CSS -->
    <link rel="stylesheet" href="../src/bootstrap4/css/bootstrap.min.css">

    <!-- MetisMenu CSS -->
    <link href="../src/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="../src/morrisjs/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../src/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">


    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>

    <![endif]-->


</head>

<body>
<div id="wrapper">

    <!-- Navigation -->
    <nav class="navbar navbar-expand-sm bg-secondary navbar-dark">
        <!-- Brand -->
        <a class="navbar-brand" href="#">
            <img src="../resources/img/templogothumb.png" alt="Logo" style="width:40px;">
        </a>

        <!-- Links -->
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a class="nav-link" href="main.php">Overview</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="data.php">Consultas</a>
            </li>
            <li class="nav-item">
                <div class="dropdown">
                    <a class="nav-link btn" data-toggle="dropdown">Gestão</a>
                    <div class="dropdown-menu" style="border-top: none !important; margin-top: -1px !important;
                    background-color: #FFF !important; border:1px solid black !important; white-space: nowrap !important; padding: 10px !important;">
                        <div class="btn-group">
                            <a type="button" class="btn btn-light nav-link" href="addComp.php" style="color: black; ">Adicionar
                                Componente</a>
                            <a type="button" class="btn btn-light nav-link" href="editComp.php" style="color: black">Editar
                                Componente</a>
                            <a type="button" class="btn btn-light nav-link" href="remComp.php" style="color: black">Remover
                                Componente</a>
                        </div>
                    </div>
                </div>
            </li>
        </ul>
        <!-- Dropdown -->

        <li class="navbar-nav dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                <i class="fa fa-user fa-fw"></i>
            </a>
            <ul class="dropdown-menu dropdown-menu-right"
                style="border-top: none; margin-top: -1px; background-color: #FFF; border:1px solid black; white-space: nowrap; padding: 10px;">
                <li><a class="dropdown-item" href="options.html"><i class="fa fa-user fa-fw"></i>Opções de Utilizador</a></li>
                <li><a class="dropdown-item" href="config.html"><i class="fa fa-gear fa-fw"></i>Configurações</a></li>
                <hr/>
                <li><a class="dropdown-item" href="../index.html"><i class="fa fa-sign-out fa-fw"></i>Logout</a></li>
            </ul>
        </li>
        <!-- /dropdown -->
    </nav>
    <div class="container-fluid">

        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Opções de Utilizador</h1>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <hr/>

        <div class="row justify-content-md-center">
            <div class="col-md-6 col-md-offset-2">
                <div class="card">
                    <div class="card-header">Adicionar Utilizador</div>
                    <div class="card-body">
                           <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group <?php echo (!empty($username_err)) ? 'has-error' : ''; ?>">
                <label>Username</label>
                <input type="text" name="username"class="form-control" value="<?php echo $username; ?>">
                <span class="help-block"><?php echo $username_err; ?></span>
            </div>    
            <div class="form-group <?php echo (!empty($password_err)) ? 'has-error' : ''; ?>">
                <label>Password</label>
                <input type="password" name="password" class="form-control" value="<?php echo $password; ?>">
                <span class="help-block"><?php echo $password_err; ?></span>
            </div>
            <div class="form-group <?php echo (!empty($confirm_password_err)) ? 'has-error' : ''; ?>">
                <label>Confirm Password</label>
                <input type="password" name="confirm_password" class="form-control" value="<?php echo $confirm_password; ?>">
                <span class="help-block"><?php echo $confirm_password_err; ?></span>
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Submit">
                <input type="reset" class="btn btn-default" value="Reset">
            </div>
            <p>Already have an account? <a href="login.php">Login here</a>.</p>
        </form>
                    </div>
                </div>
                <hr>
                <div class="card">
                    <div class="card-header">Alterar Password</div>
                    <div class="card-body">
                        <form action="action_change_pw.php">
                            <div class="form-group">
                                <label for="username">Username:</label>
                                <input class="form-control" id="username" placeholder="Username" name="username" type="text" autofocus>
                            </div>
                            <div class="form-group">
                                <label for="passwordOld">Password actual:</label>
                                <input class="form-control" id="passwordOld" placeholder="Password" name="passwordOld" type="password" value="">
                            </div>
                            <div class="form-group">
                                <label for="passwordNew">Nova password:</label>
                                <input class="form-control" id="passwordNew" placeholder="Password" name="passwordOld" type="password" value="">
                            </div>
                            <!-- Change this to a button or input when using this as a form -->
                            <button type="submit" class="btn btn-primary">Alterar Password</button>
                        </form>
                    </div>
                </div>
                <hr>
                <div class="card">
                    <div class="card-header">Remover Utilizador</div>
                    <div class="card-body">
                        <form action="action_rem_user.php">
                            <div class="form-group">
                                <label for="remuser">Quadro:</label>
                                <select class="form-control" id="remuser" name="remuser">
                                    <option>Utilizador 1</option>
                                    <option>Utilizador 2</option>
                                    <option>Utilizador 3</option>
                                    <option>Utilizador 4</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="rempassword">Password actual:</label>
                                <input class="form-control" id="rempassword" placeholder="Password" name="password" type="rempassword" value="">
                            </div>
                            <!-- Change this to a button or input when using this as a form -->
                            <button type="submit" class="btn btn-primary">Remover Utilizador</button>
                        </form>
                    </div>
                </div>
                <hr>
            </div>
        </div>
    </div>
</div>
</body>
</html>