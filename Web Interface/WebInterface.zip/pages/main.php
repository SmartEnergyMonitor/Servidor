<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Smart Energy Monitor</title>

    <script src="../src/jquery/jquery.min.js"></script>
    <script src="../src/popper/popper.min.js.html"></script>
    <script src="../src/bootstrap4/js/bootstrap.min.js"></script>


    <!-- Bootstrap Core CSS -->

    <link rel="stylesheet" href="../src/bootstrap4/css/bootstrap.min.css">

    <!-- MetisMenu CSS -->
    <link href="../src/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="../src/morrisjs/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../src/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">


    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>
<div id="wrapper">

    <!-- Navigation -->
    <nav class="navbar navbar-expand-sm bg-secondary navbar-dark">
        <!-- Brand -->
        <a class="navbar-brand" href="#">
            <img src="../resources/img/templogothumb.png" alt="Logo" style="width:40px;">
        </a>

        <!-- Links -->
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a class="nav-link" href="main.php">Overview</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="data.php">Consultas</a>
            </li>
            <li class="nav-item">
                <div class="dropdown">
                    <a class="nav-link btn" data-toggle="dropdown" >Gestão</a>
                    <div class="dropdown-menu"  style="border-top: none !important; margin-top: -1px !important;
                    background-color: #FFF !important; border:1px solid black !important; white-space: nowrap !important; padding: 10px !important;">
                        <div class="btn-group">
                            <a type="button" class="btn btn-light nav-link" href="addComp.php" style="color: black; ">Adicionar Componente</a>
                            <a type="button" class="btn btn-light nav-link" href="editComp.php" style="color: black">Editar Componente</a>
                            <a type="button" class="btn btn-light nav-link" href="remComp.php" style="color: black">Remover Componente</a>
                        </div>
                    </div>
                </div>
            </li>
        </ul>
        <!-- Dropdown -->

        <li class="navbar-nav dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                <i class="fa fa-user fa-fw"></i>
            </a>
            <ul class="dropdown-menu dropdown-menu-right"
                style="border-top: none; margin-top: -1px; background-color: #FFF; border:1px solid black; white-space: nowrap; padding: 10px;">
                <li><a class="dropdown-item" href="options.html"><i class="fa fa-user fa-fw"></i>Opções de Utilizador</a></li>
                <li><a class="dropdown-item" href="config.html"><i class="fa fa-gear fa-fw"></i>Configurações</a></li>
                <hr/>
                <li><a class="dropdown-item" href="../index.html"><i class="fa fa-sign-out fa-fw"></i>Logout</a></li>
            </ul>
        </li>
        <!-- /dropdown -->
    </nav>
    <!-- /Navigation -->


    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Overview</h1>
            </div>
            <!-- /.col-lg-12 -->
        </div>

        <hr/>
        <!-- Password alert -->
        <div class="row">
            <div class="col-md-2 col-md-offset-1"></div>
            <div class="col-md-8 col-md-offset-1">
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    Aviso: Por motivos de segurança, é recomendado adicionar uma password ao utilizador root. <a
                        href="#" class="alert-link">Alterar Password</a>.
                </div>
            </div>
        </div>
        <!-- /Password alert -->

        <div class="row">
            <div class="col-md-3 col-md-offset-1"> <!-- primeira tabela -->
                <div class="card">
                    <div class="card-header">Consumos - Top 5</div>
                    <div class="card-body" style="padding-bottom: 0px">
                        <div class="flot-chart">
                            <div class="flot-chart-content" id="flot-pie-chart-1"
                                 style="padding: 0px; position: relative;">
                                <canvas class="flot-base"
                                        style="direction: ltr; position: absolute; left: 0px; top: 0px; width: 749px; height: 400px;"
                                        width="749" height="400"></canvas>
                                <canvas class="flot-overlay"
                                        style="direction: ltr; position: absolute; left: 0px; top: 0px; width: 749px; height: 400px;"
                                        width="749" height="400"></canvas>

                            </div>
                        </div> <!-- Pie chart -->
                        <p>
                        <hr/>
                        <div class="table-responsive">
                            <table class="table">
                                <thead class="thead-light">
                                <tr>
                                    <th>Circuito</th>
                                    <th>Valor</th>
                                    <th>%</th>
                                </tr>
                                </thead>
                                <tbody id="top5table">

                                </tbody>
                            </table> <!-- Tabela -->
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-9 col-md-offset">
                <div class="row">
                    <div class="col-md-4 col-md-offset-1">
                        <div class="card">
                            <div class="card-header">Número de Quadros Activos</div>
                            <div class="card-body" id="NumberOfQuadros">

                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-md-offset-1">
                        <div class="card">
                            <div class="card-header">Número de Nós Activos</div>
                            <div class="card-body" id="NumberOfNodes">

                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-md-offset-1">
                        <div class="card">
                            <div class="card-header">Número de Sensores Activos</div>
                            <div class="card-body" id="NumberOfSensors">

                            </div>
                        </div>
                    </div>
                </div>
                <p></p>
                <div class="row">

                    <div class="col-md-12 col-md-offset-1">
                        <div class="card">
                            <div class="card-header">Consumos</div>
                            <div class="card-body">
                                <div class="form-group">
                                    <label for="sel1">Selecione circuito:</label>
                                    <select class="form-control" id="sel1" name="sellist1">
                                        <option id="static-mainSensorChart" style="display: block">Selecione Sensor</option>
                                        <?php
                                        include("../services/dbConn.php");
                                        $sql = "SELECT SensorID, Alias FROM Sensor";
                                        $result = mysqli_query($db,$sql);
                                        while ($rowCerts = $result->fetch_assoc()) {
                                            echo "<option value=\"{$rowCerts['SensorID']}\" class = \"sensorDropdownChartID\">";
                                            echo $rowCerts['Alias'];
                                            echo "</option>\n";
                                        }
                                        mysqli_close($db);
                                        ?>
                                    </select>
                                </div>
                                <div class="panel panel-default">

                                    <!-- /.panel-heading -->
                                    <div class="panel-body">
                                        <div class="flot-chart">
                                            <div class="flot-chart-content" id="flot-line-chart-multi"
                                                 style="padding: 0px; position: relative;">
                                                <canvas class="flot-base"
                                                        style="direction: ltr; position: absolute; left: 0px; top: 0px; width: 749px; height: 400px;"
                                                        width="749" height="400"></canvas>
                                                <div class="flot-text"
                                                     style="position: absolute; top: 0px; left: 0px; bottom: 0px; right: 0px; font-size: smaller; color: rgb(84, 84, 84);">
                                                    <div class="flot-x-axis flot-x1-axis xAxis x1Axis"
                                                         style="position: absolute; top: 0px; left: 0px; bottom: 0px; right: 0px;">
                                                    </div>
                                                    <div class="flot-y-axis flot-y1-axis yAxis y1Axis"
                                                         style="position: absolute; top: 0px; left: 0px; bottom: 0px; right: 0px;">
                                                    </div>
                                                    <div class="flot-y-axis flot-y2-axis yAxis y2Axis"
                                                         style="position: absolute; top: 0px; left: 0px; bottom: 0px; right: 0px;">
                                                    </div>
                                                </div>
                                                <canvas class="flot-overlay"
                                                        style="direction: ltr; position: absolute; left: 0px; top: 0px; width: 749px; height: 400px;"
                                                        width="749" height="400"></canvas>
                                                <div class="legend">
                                                    <div style="position: absolute; width: 149px; height: 33.3333px; bottom: 29px; left: 33px; background-color: rgb(255, 255, 255); opacity: 0.85;"></div>
                                                    <table style="position:absolute;bottom:29px;left:33px;;font-size:smaller;color:#545454">

                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- /.panel-body -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="../js/main.js"></script>

<script src="../src/jquery/jquery.min.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="../src/bootstrap/js/bootstrap.min.js"></script>

<!-- Metis Menu Plugin JavaScript -->
<script src="../src/metisMenu/metisMenu.min.js"></script>

<!-- Flot Graphics Scripts -->
<script src="../src/flot/excanvas.min.js"></script>
<script src="../src/flot/jquery.flot.js"></script>
<script src="../src/flot/jquery.flot.pie.js"></script>
<script src="../src/flot/jquery.flot.resize.js"></script>
<script src="../src/flot/jquery.flot.time.js"></script>
<script src="../src/flot-tooltip/jquery.flot.tooltip.min.js"></script>
<!--<script src="../placeholders/js/overview-pie-ph.js"></script>-->
</body>