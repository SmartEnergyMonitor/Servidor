<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Smart Energy Monitor</title>

    <script src="../src/jquery/jquery.min.js"></script>
    <script src="../src/popper/popper.min.js.html"></script>
    <script src="../src/bootstrap4/js/bootstrap.min.js"></script>


    <!-- Bootstrap Core CSS -->
    <link rel="stylesheet" href="../src/bootstrap4/css/bootstrap.min.css">

    <!-- MetisMenu CSS -->
    <link href="../src/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="../src/morrisjs/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../src/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">


    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>

    <![endif]-->


</head>

<body>
<div id="wrapper">

    <!-- Navigation -->
    <nav class="navbar navbar-expand-sm bg-secondary navbar-dark">
        <!-- Brand -->
        <a class="navbar-brand" href="#">
            <img src="../resources/img/templogothumb.png" alt="Logo" style="width:40px;">
        </a>

        <!-- Links -->
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a class="nav-link" href="main.php">Overview</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="data.php">Consultas</a>
            </li>
            <li class="nav-item">
                <div class="dropdown">
                    <a class="nav-link btn" data-toggle="dropdown">Gestão</a>
                    <div class="dropdown-menu" style="border-top: none !important; margin-top: -1px !important;
                    background-color: #FFF !important; border:1px solid black !important; white-space: nowrap !important; padding: 10px !important;">
                        <div class="btn-group">
                            <a type="button" class="btn btn-light nav-link" href="addComp.php" style="color: black; ">Adicionar
                                Componente</a>
                            <a type="button" class="btn btn-light nav-link" href="editComp.php" style="color: black">Editar
                                Componente</a>
                            <a type="button" class="btn btn-light nav-link" href="remComp.php" style="color: black">Remover
                                Componente</a>
                        </div>
                    </div>
                </div>
            </li>
        </ul>
        <!-- Dropdown -->

        <li class="navbar-nav dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                <i class="fa fa-user fa-fw"></i>
            </a>
            <ul class="dropdown-menu dropdown-menu-right"
                style="border-top: none; margin-top: -1px; background-color: #FFF; border:1px solid black; white-space: nowrap; padding: 10px;">
                <li><a class="dropdown-item" href="options.html"><i class="fa fa-user fa-fw"></i>Opções de Utilizador</a></li>
                <li><a class="dropdown-item" href="config.html"><i class="fa fa-gear fa-fw"></i>Configurações</a></li>
                <hr/>
                <li><a class="dropdown-item" href="../index.html"><i class="fa fa-sign-out fa-fw"></i>Logout</a></li>
            </ul>
        </li>
        <!-- /dropdown -->
    </nav>
    <!-- /Navigation -->
    <div id="debug">

    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Remover Componente</h1>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <hr/>

        <div class="row justify-content-md-center">
            <div class="col-md-8 col-md-offset-2">
                <div class="card">
                    <div class="card-header">Componentes</div>
                    <div class="card-body">
                        <!-- Nav pills -->
                        <ul class="nav nav-tabs justify-content-center" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" data-toggle="tab" href="#quadroRem">Quadro</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" data-toggle="tab" href="#nodeRem">Nó</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" data-toggle="tab" href="#sensorRem">Circuito</a>
                            </li>
                        </ul>
                        <!-- tabs -->
                        <div class="tab-content">

                            <!-- Remover Quadro -->

                            <div id="quadroRem" class="container tab-pane active"><br>
                                <h3>Remover Quadro</h3>
                                <form method="post">
                                    <div class="form-group">
                                        <label for="remQuadroID">Quadro:</label>
                                        <select class="form-control" id="remQuadroID" name="remQuadroID">
                                            <?php
                                            include("../services/dbConn.php");
                                            $sql = "SELECT QuadroID, Alias FROM Quadro";
                                            $result = mysqli_query($db,$sql);
                                            while ($rowCerts = $result->fetch_assoc()) {
                                                echo "<option value=\"{$rowCerts['QuadroID']}\" class = \"quadroRemoveDropdownID\">";
                                                echo $rowCerts['Alias'];
                                                echo "</option>\n";
                                            }
                                            mysqli_close($db);
                                            ?>
                                        </select>
                                    </div>
                                    <hr>
                                    <button type="submit" class="btn btn-primary" id="remQuadro">Remover</button>
                                </form>
                            </div>

                            <!-- Remover node -->

                            <div id="nodeRem" class="container tab-pane fade"><br>
                                <h3>Remover Nó</h3>
                                <form method="post">
                                    <div class="form-group" id="idQuadroRomoveNodeForm">
                                        <label for="quadroNodeOld">Quadro:</label>
                                        <select class="form-control" id="quadroNodeOld" name="quadroNodeOld">
                                            <option id="static-quadroRemoveNode" style="display: block">Selecione Quadro</option>
                                            <?php
                                            include("../services/dbConn.php");
                                            $sql = "SELECT QuadroID, Alias FROM Quadro";
                                            $result = mysqli_query($db,$sql);
                                            while ($rowCerts = $result->fetch_assoc()) {
                                                echo "<option value=\"{$rowCerts['QuadroID']}\" class = \"quadroRemoveNodeDropdownID\">";
                                                echo $rowCerts['Alias'];
                                                echo "</option>\n";
                                            }
                                            mysqli_close($db);
                                            ?>
                                        </select>
                                    </div>
                                    <div class="form-group" id="idNodeRemoveNodeForm">
                                        <label for="nodeOld">Nó a Remover:</label>
                                        <select class="form-control" id="nodeOld" name="nodeOld">
                                            <option id="static-NodeRemoveNode" style="display: block">Select node</option>
                                        </select>
                                    </div>
                                    <hr>
                                    <button type="submit" class="btn btn-primary" id="remNode">Remover</button>
                                </form>
                            </div>

                            <!-- Remover Sensor -->

                            <div id="sensorRem" class="container tab-pane fade"><br>
                                <h3>Remover Nó</h3>
                                <form method="post">
                                    <div class="form-group" id="idQuadroRemoveSensorForm">
                                        <label for="quadroNodeSensorOld">Quadro:</label>
                                        <select class="form-control" id="quadroNodeSensorOld" name="quadroNodeSensorOld">
                                            <option id="static-quadroRemoveSensor" style="display: block">Selecione Quadro</option>
                                            <?php
                                            include("../services/dbConn.php");
                                            $sql = "SELECT QuadroID, Alias FROM Quadro";
                                            $result = mysqli_query($db,$sql);
                                            while ($rowCerts = $result->fetch_assoc()) {
                                                echo "<option value=\"{$rowCerts['QuadroID']}\" class = \"quadroRemoveSensorDropdownID\">";
                                                echo $rowCerts['Alias'];
                                                echo "</option>\n";
                                            }
                                            mysqli_close($db);
                                            ?>
                                        </select>
                                    </div>
                                    <div class="form-group" id="idNodeRemoveSensorForm">
                                        <label for="nodeSensorOld">Nó:</label>
                                        <select class="form-control" id="nodeSensorOld" name="nodeSensorOld">
                                            <option id="static-nodeRemoveNode" style="display: block">Selecione Nó</option>
                                        </select>
                                    </div>
                                    <div class="form-group" id="idSensorRemoveSensorForm">
                                        <label for="sensorOld">Circuito a Remover:</label>
                                        <select class="form-control" id="sensorOld" name="sensorOld">
                                            <option id="static-sensorRemoveSensor" style="display: block">Selecione Circuito</option>
                                        </select>
                                    </div>
                                    <hr>
                                    <button type="submit" class="btn btn-primary" id="remSensor">Remover</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="../js/remComp.js"></script>
</div>
</body>
</html>